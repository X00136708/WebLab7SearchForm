const Header = () => (
<div>
	<h2>Header</h2>
</div>
)
export default Header;