import Nav from './Nav' 



const layoutStyle = {
  h2: {
    color: 'red',
    fontSize: 19
  }
  
}


const Layout = (props) => (
  <div style={layoutStyle}>
    
    <Nav />
    {props.children}
  </div>
)

export default Layout