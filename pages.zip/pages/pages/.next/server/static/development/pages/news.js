module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 4);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./components/SearchForm.js":
/*!**********************************!*\
  !*** ./components/SearchForm.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SearchForm; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _jsxFileName = "C:\\Users\\x00136708\\Downloads\\pages\\pages\\components\\SearchForm.js";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 //
// Define SearchForm Class
//

var SearchForm =
/*#__PURE__*/
function (_Component) {
  _inherits(SearchForm, _Component);

  // constructor accepts props and initialises state
  function SearchForm(props) {
    var _this;

    _classCallCheck(this, SearchForm);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(SearchForm).call(this, props));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "formSubmitted", function (event) {
      // Validate input value
      if (event.target.newsSource.value != "") {
        // setNewsSource is a function passed from parent (news page) via props
        // It is used as a way to pass the input value back up to the parent
        // This is called state lifting
        // see: https://reactjs.org/docs/lifting-state-up.html
        _this.props.setNewsSource(event.target.newsSource.value);
      } // prevent page reload (prevent submit)


      event.preventDefault();
    });

    _this.state = {};
    return _this;
  } // end Constructor
  //
  // an event handler for form submit
  //


  _createClass(SearchForm, [{
    key: "render",
    // end formSubmitted
    // Render the form
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 57
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        id: "search",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 61
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h3", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 63
        },
        __self: this
      }, "Enter newsapi.org source"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("form", {
        onSubmit: this.formSubmitted,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 67
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("input", {
        name: "newsSource",
        placeholder: "News Source name",
        type: "text",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 71
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("button", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 83
        },
        __self: this
      }, "Update News"))));
    }
  }]);

  return SearchForm;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]); // end Render




/***/ }),

/***/ "./pages/news.js":
/*!***********************!*\
  !*** ./pages/news.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return News; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "@babel/runtime/regenerator");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "next/link");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! isomorphic-unfetch */ "isomorphic-unfetch");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_SearchForm__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/SearchForm */ "./components/SearchForm.js");

var _jsxFileName = "C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }




var apiKey = '3780066b33ef41b9b4b7e957994e9c38';
var defaultNewsSource = 'the-irish-times';

function getNews(_x) {
  return _getNews.apply(this, arguments);
}

function _getNews() {
  _getNews = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3(url) {
    var res, data;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            _context3.next = 3;
            return isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4___default()(url);

          case 3:
            res = _context3.sent;
            _context3.next = 6;
            return res.json();

          case 6:
            data = _context3.sent;
            return _context3.abrupt("return", data);

          case 10:
            _context3.prev = 10;
            _context3.t0 = _context3["catch"](0);
            return _context3.abrupt("return", _context3.t0);

          case 13:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 10]]);
  }));
  return _getNews.apply(this, arguments);
}

var News =
/*#__PURE__*/
function (_React$Component) {
  _inherits(News, _React$Component);

  function News(props) {
    var _this;

    _classCallCheck(this, News);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(News).call(this, props));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "setNewsSource", function (input) {
      _this.setState({
        newsSource: input,
        url: "https://newsapi.org/v2/top-headlines?sources=".concat(input, "&apiKey=").concat(apiKey)
      });
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "searchNewsAPI", function (event) {
      _this.setState({
        newsSource: "".concat(event.target.innerText),
        url: "https://newsapi.org/v2/".concat(event.target.name, "$apiKey=").concat(apiKey)
      });

      console.log(_this.state.url);
    });

    _this.state = {
      newsSource: "",
      url: "",
      articles: []
    };
    return _this;
  }

  _createClass(News, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      if (this.state.articles.length == 0) {
        this.state.articles = this.props.articles;
      }

      return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
        className: "jsx-178785908",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 52
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_components_SearchForm__WEBPACK_IMPORTED_MODULE_5__["default"], {
        setNewsSource: this.setNewsSource,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 53
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("ul", {
        className: "jsx-178785908" + " " + "newsMenu",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 56
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("li", {
        className: "jsx-178785908",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 57
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
        href: "a",
        onClick: this.searchNewsAPI,
        name: "top-headlines?country=ie",
        className: "jsx-178785908",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 57
        },
        __self: this
      }, "Top Headlines Ireland")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("li", {
        className: "jsx-178785908",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 58
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
        href: "a",
        onClick: this.searchNewsAPI,
        name: "top-headlines?country=ie&category=business",
        className: "jsx-178785908",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 58
        },
        __self: this
      }, "Business News Ireland")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("li", {
        className: "jsx-178785908",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 59
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
        href: "a",
        onClick: this.searchNewsAPI,
        name: "everything?q=technology",
        className: "jsx-178785908",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 59
        },
        __self: this
      }, "Technology News")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("li", {
        className: "jsx-178785908",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 60
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
        href: "a",
        onClick: this.searchNewsAPI,
        name: "top-headlines?country=ie&category=weather",
        className: "jsx-178785908",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 60
        },
        __self: this
      }, "Weather in Ireland"))), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("h3", {
        className: "jsx-178785908",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 63
        },
        __self: this
      }, this.state.newsSource.split("-").join(" ")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
        className: "jsx-178785908",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 64
        },
        __self: this
      }, this.state.articles.map(function (article, index) {
        return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("section", {
          key: index,
          className: "jsx-178785908",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 68
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("h3", {
          className: "jsx-178785908",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 69
          },
          __self: this
        }, article.title), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-178785908" + " " + "author",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 70
          },
          __self: this
        }, article.author, " ", article.publishedAt), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("img", {
          src: article.urlToImage,
          alt: "article image",
          className: "jsx-178785908" + " " + "img-article",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 71
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-178785908",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 72
          },
          __self: this
        }, article.description), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-178785908",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 73
          },
          __self: this
        }, article.content), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-178785908",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 74
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
          href: "/story",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 74
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
          className: "jsx-178785908",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 74
          },
          __self: this
        }, "Read More"))), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          onClick: _this2.test,
          className: "jsx-178785908",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 75
          },
          __self: this
        }, "click.."));
      })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a, {
        styleId: "178785908",
        css: "section.jsx-178785908{width:50%;border:1px solid gray;background-color:rgb(240,248,255);padding:1em;margin:1em;}.author.jsx-178785908{font-style:italic;font-size:0.8em;}.img-article.jsx-178785908{max-width:50%;}.newsMenu.jsx-178785908{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;margin:0;padding:0;margin-top:20px;}.newsMenu.jsx-178785908 li.jsx-178785908{display:inline-table;padding-left:20px;}.newsMenu.jsx-178785908 li.jsx-178785908 a.jsx-178785908{font-size:1em;color:blue;display:block;-webkit-text-decoration:none;text-decoration:none;}.newsMenu.jsx-178785908 li.jsx-178785908 a.jsx-178785908:hover{color:rgb(255,187,0);-webkit-text-decoration:underline;text-decoration:underline;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xceDAwMTM2NzA4XFxEb3dubG9hZHNcXHBhZ2VzXFxwYWdlc1xccGFnZXNcXG5ld3MuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBK0VnQixBQUtnQixBQVFRLEFBSUosQUFHQSxBQU9RLEFBSVAsQUFNTyxVQS9CQSxJQVl0QixBQWNZLElBbEJJLEdBY0csQUFVUSxJQUxaLE9BMUJxQixFQVFwQyxLQWNBLEFBS3NCLDJCQTFCVixRQWFRLElBWlQsR0E4QlgsUUE3QkEsQUF5QkEsc0RBYlUsU0FDQyxVQUNNLGdCQUNqQiIsImZpbGUiOiJDOlxcVXNlcnNcXHgwMDEzNjcwOFxcRG93bmxvYWRzXFxwYWdlc1xccGFnZXNcXHBhZ2VzXFxuZXdzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcclxuaW1wb3J0IGZldGNoIGZyb20gJ2lzb21vcnBoaWMtdW5mZXRjaCc7XHJcbmltcG9ydCBTZWFyY2hGb3JtIGZyb20gJy4uL2NvbXBvbmVudHMvU2VhcmNoRm9ybSc7XHJcbmNvbnN0IGFwaUtleSA9ICczNzgwMDY2YjMzZWY0MWI5YjRiN2U5NTc5OTRlOWMzOCc7XHJcbmNvbnN0IGRlZmF1bHROZXdzU291cmNlID0gJ3RoZS1pcmlzaC10aW1lcydcclxuXHRcdFx0XHJcbmFzeW5jIGZ1bmN0aW9uIGdldE5ld3ModXJsKSB7XHJcbnRyeSB7XHJcblx0Y29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsKTtcclxuXHRjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuXHRyZXR1cm4gKGRhdGEpO1xyXG59IGNhdGNoIChlcnJvcikge1xyXG5cdHJldHVybiAoZXJyb3IpO1xyXG59XHJcbn1cdFxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBOZXdzIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50IHtcclxuXHJcbmNvbnN0cnVjdG9yKHByb3BzKSB7XHJcblx0c3VwZXIocHJvcHMpXHJcblx0dGhpcy5zdGF0ZSA9IHtcclxuXHRcdG5ld3NTb3VyY2U6IFwiXCIsXHJcblx0XHR1cmw6IFwiXCIsXHJcblx0XHRhcnRpY2xlczogW11cclxuXHR9XHJcbn0gXHJcblxyXG5zZXROZXdzU291cmNlID0gKGlucHV0KSA9PiB7XHJcblx0dGhpcy5zZXRTdGF0ZSh7XHJcblx0XHRuZXdzU291cmNlOiBpbnB1dCxcclxuXHRcdHVybDogYGh0dHBzOi8vbmV3c2FwaS5vcmcvdjIvdG9wLWhlYWRsaW5lcz9zb3VyY2VzPSR7aW5wdXR9JmFwaUtleT0ke2FwaUtleX1gXHJcblx0fSlcclxufVxyXG5cclxuc2VhcmNoTmV3c0FQSSA9IChldmVudCkgPT4ge1xyXG5cdHRoaXMuc2V0U3RhdGUoe1xyXG5cdFx0bmV3c1NvdXJjZTogYCR7ZXZlbnQudGFyZ2V0LmlubmVyVGV4dH1gLFxyXG5cdFx0dXJsOiBgaHR0cHM6Ly9uZXdzYXBpLm9yZy92Mi8ke2V2ZW50LnRhcmdldC5uYW1lfSRhcGlLZXk9JHthcGlLZXl9YFxyXG5cdH0pXHJcblx0Y29uc29sZS5sb2codGhpcy5zdGF0ZS51cmwpO1xyXG59XHJcblxyXG5yZW5kZXIoKSB7XHJcblxyXG5cdGlmICh0aGlzLnN0YXRlLmFydGljbGVzLmxlbmd0aCA9PSAwKSB7XHJcblxyXG5cdFx0dGhpcy5zdGF0ZS5hcnRpY2xlcyA9IHRoaXMucHJvcHMuYXJ0aWNsZXM7XHJcblxyXG5cdH1cclxuXHJcblx0cmV0dXJuIChcclxuXHJcblx0XHQ8ZGl2PlxyXG5cdFx0PFNlYXJjaEZvcm0gc2V0TmV3c1NvdXJjZT17dGhpcy5zZXROZXdzU291cmNlfS8+XHJcblx0XHRcclxuXHRcdFxyXG5cdFx0PHVsIGNsYXNzTmFtZT1cIm5ld3NNZW51XCI+XHJcblx0XHRcdDxsaT48YSBocmVmPVwiYVwiIG9uQ2xpY2s9e3RoaXMuc2VhcmNoTmV3c0FQSX0gbmFtZT1cInRvcC1oZWFkbGluZXM/Y291bnRyeT1pZVwiPlRvcCBIZWFkbGluZXMgSXJlbGFuZDwvYT48L2xpPlxyXG5cdFx0XHQ8bGk+PGEgaHJlZj1cImFcIiBvbkNsaWNrPXt0aGlzLnNlYXJjaE5ld3NBUEl9IG5hbWU9XCJ0b3AtaGVhZGxpbmVzP2NvdW50cnk9aWUmY2F0ZWdvcnk9YnVzaW5lc3NcIj5CdXNpbmVzcyBOZXdzIElyZWxhbmQ8L2E+PC9saT5cclxuXHRcdFx0PGxpPjxhIGhyZWY9XCJhXCIgb25DbGljaz17dGhpcy5zZWFyY2hOZXdzQVBJfSBuYW1lPVwiZXZlcnl0aGluZz9xPXRlY2hub2xvZ3lcIj5UZWNobm9sb2d5IE5ld3M8L2E+PC9saT5cclxuXHRcdFx0PGxpPjxhIGhyZWY9XCJhXCIgb25DbGljaz17dGhpcy5zZWFyY2hOZXdzQVBJfSBuYW1lPVwidG9wLWhlYWRsaW5lcz9jb3VudHJ5PWllJmNhdGVnb3J5PXdlYXRoZXJcIj5XZWF0aGVyIGluIElyZWxhbmQ8L2E+PC9saT5cclxuXHRcdDwvdWw+XHJcblx0XHRcclxuXHRcdDxoMz57dGhpcy5zdGF0ZS5uZXdzU291cmNlLnNwbGl0KFwiLVwiKS5qb2luKFwiIFwiKX08L2gzPlxyXG5cdFx0XHQ8ZGl2PlxyXG5cclxuXHJcblx0XHRcdHt0aGlzLnN0YXRlLmFydGljbGVzLm1hcCgoYXJ0aWNsZSwgaW5kZXgpID0+IChcclxuXHRcdFx0XHQ8c2VjdGlvbiBrZXk9e2luZGV4fT5cclxuXHRcdFx0XHQ8aDM+e2FydGljbGUudGl0bGV9PC9oMz5cclxuXHRcdFx0XHQ8cCBjbGFzc05hbWU9XCJhdXRob3JcIj57YXJ0aWNsZS5hdXRob3J9IHthcnRpY2xlLnB1Ymxpc2hlZEF0fTwvcD5cclxuXHRcdFx0XHQ8aW1nIHNyYz17YXJ0aWNsZS51cmxUb0ltYWdlfSBhbHQ9XCJhcnRpY2xlIGltYWdlXCIgY2xhc3NOYW1lPVwiaW1nLWFydGljbGVcIj48L2ltZz5cclxuXHRcdFx0XHQ8cD57YXJ0aWNsZS5kZXNjcmlwdGlvbn08L3A+XHJcblx0XHRcdFx0PHA+e2FydGljbGUuY29udGVudH08L3A+XHJcblx0XHRcdFx0PHA+PExpbmsgaHJlZj1cIi9zdG9yeVwiPjxhPlJlYWQgTW9yZTwvYT48L0xpbms+PC9wPlxyXG5cdFx0XHRcdDxwIG9uQ2xpY2s9e3RoaXMudGVzdH0+Y2xpY2suLjwvcD5cclxuXHRcdFx0XHQ8L3NlY3Rpb24+XHJcblx0XHRcdCkpfVxyXG5cclxuXHRcdFx0PC9kaXY+XHRcdFxyXG5cdFx0XHRcdDxzdHlsZSBqc3g+e2BcclxuXHJcblx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdHNlY3Rpb24ge1xyXG5cdFx0XHRcdFx0d2lkdGg6IDUwJTtcclxuXHRcdFx0XHRcdGJvcmRlcjogMXB4IHNvbGlkIGdyYXk7XHJcblx0XHRcdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjQwLCAyNDgsIDI1NSk7XHJcblx0XHRcdFx0XHRwYWRkaW5nOiAxZW07XHJcblx0XHRcdFx0XHRtYXJnaW46IDFlbTtcclxuXHRcdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0XHQuYXV0aG9yIHtcclxuXHRcdFx0XHRcdGZvbnQtc3R5bGU6IGl0YWxpYztcclxuXHRcdFx0XHRcdGZvbnQtc2l6ZTogMC44ZW07XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHQuaW1nLWFydGljbGUge1xyXG5cdFx0XHRcdFx0bWF4LXdpZHRoOiA1MCU7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHQubmV3c01lbnV7XHJcblx0XHRcdFx0XHRcdGRpc3BsYXk6IGZsZXg7XHJcblx0XHRcdFx0XHRcdGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcblx0XHRcdFx0XHRcdG1hcmdpbjogMDtcclxuXHRcdFx0XHRcdFx0cGFkZGluZzogMDtcclxuXHRcdFx0XHRcdFx0bWFyZ2luLXRvcDogMjBweDtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdC5uZXdzTWVudSBsaXtcclxuXHRcdFx0XHRcdFx0ZGlzcGxheTogaW5saW5lLXRhYmxlO1xyXG5cdFx0XHRcdFx0XHRwYWRkaW5nLWxlZnQ6IDIwcHg7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHQubmV3c01lbnUgbGkgYXtcclxuXHRcdFx0XHRcdFx0Zm9udC1zaXplOiAxZW07XHJcblx0XHRcdFx0XHRcdGNvbG9yOiBibHVlO1xyXG5cdFx0XHRcdFx0XHRkaXNwbGF5OiBibG9jaztcclxuXHRcdFx0XHRcdFx0dGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0Lm5ld3NNZW51IGxpIGE6aG92ZXIge1xyXG5cdFx0XHRcdFx0XHRjb2xvcjogcmdiKDI1NSwxODcsMCk7XHJcblx0XHRcdFx0XHRcdHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0YH1cclxuXHRcdFx0XHQ8L3N0eWxlPlxyXG5cclxuXHRcdDwvZGl2PlxyXG5cclxuXHQpO1xyXG5cclxufSBcclxuc3RhdGljIGFzeW5jIGdldEluaXRpYWxQcm9wcyhyZXNwb25zZSkge1xyXG5cdGNvbnN0IGluaXRVcmwgPSBgaHR0cHM6Ly9uZXdzYXBpLm9yZy92Mi90b3AtaGVhZGxpbmVzP3NvdXJjZXM9JHtkZWZhdWx0TmV3c1NvdXJjZX0mYXBpS2V5PSR7YXBpS2V5fWA7XHJcblx0Y29uc3QgZGF0YSA9IGF3YWl0IGdldE5ld3MoaW5pdFVybCk7XHJcblxyXG5cclxuXHJcblx0XHRpZiAoQXJyYXkuaXNBcnJheShkYXRhLmFydGljbGVzKSkge1xyXG5cclxuXHRcdFx0cmV0dXJuIHtcclxuXHRcdFx0XHRhcnRpY2xlczogZGF0YS5hcnRpY2xlc1xyXG5cclxuXHRcdFx0fVxyXG5cclxuXHRcdH1cclxuXHJcblxyXG5cdFx0ZWxzZSB7XHJcblxyXG5cdFx0XHRjb25zb2xlLmVycm9yKGRhdGEpXHJcblxyXG5cdFx0XHRcdGlmIChyZXNwb25zZSkge1xyXG5cclxuXHRcdFx0XHRyZXNwb25zZS5zdGF0dXNDb2RlID0gNDAwXHJcblxyXG5cdFx0XHRcdHJlc3BvbnNlLmVuZChkYXRhLm1lc3NhZ2UpO1xyXG5cclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0fVxyXG5cclxufVxyXG5hc3luYyBjb21wb25lbnREaWRVcGRhdGUocHJldlByb3BzLCBwcmV2U3RhdGUpIHtcclxuXHRpZiAodGhpcy5zdGF0ZS51cmwgIT09IHByZXZTdGF0ZS51cmwpIHtcclxuXHRcdGNvbnN0IGRhdGEgPSBhd2FpdCBnZXROZXdzKHRoaXMuc3RhdGUudXJsKTtcclxuXHRcdFx0aWYgKEFycmF5LmlzQXJyYXkoZGF0YS5hcnRpY2xlcykpIHtcclxuXHRcdFx0XHR0aGlzLnN0YXRlLmFydGljbGVzID0gZGF0YS5hcnRpY2xlcztcclxuXHRcdFx0XHR0aGlzLnNldFN0YXRlKHRoaXMuc3RhdGUpO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0ZWxzZSB7XHJcblx0XHRcdGNvbnNvbGUuZXJyb3IoZGF0YSlcclxuXHRcdFx0XHRpZiAocmVzcG9uc2UpIHtcclxuXHRcdFx0XHRcdHJlc3BvbnNlLnN0YXR1c0NvZGUgPSA0MDBcclxuXHRcdFx0XHRcdHJlc3BvbnNlLmVuZChkYXRhLm1lc3NhZ2UpO1xyXG5cclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0fVxyXG5cclxuXHR9XHJcblxyXG59IH1cclxuIl19 */\n/*@ sourceURL=C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js */",
        __self: this
      }));
    }
  }, {
    key: "componentDidUpdate",
    value: function () {
      var _componentDidUpdate = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(prevProps, prevState) {
        var data;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!(this.state.url !== prevState.url)) {
                  _context.next = 5;
                  break;
                }

                _context.next = 3;
                return getNews(this.state.url);

              case 3:
                data = _context.sent;

                if (Array.isArray(data.articles)) {
                  this.state.articles = data.articles;
                  this.setState(this.state);
                } else {
                  console.error(data);

                  if (response) {
                    response.statusCode = 400;
                    response.end(data.message);
                  }
                }

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      return function componentDidUpdate(_x2, _x3) {
        return _componentDidUpdate.apply(this, arguments);
      };
    }()
  }], [{
    key: "getInitialProps",
    value: function () {
      var _getInitialProps = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(response) {
        var initUrl, data;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                initUrl = "https://newsapi.org/v2/top-headlines?sources=".concat(defaultNewsSource, "&apiKey=").concat(apiKey);
                _context2.next = 3;
                return getNews(initUrl);

              case 3:
                data = _context2.sent;

                if (!Array.isArray(data.articles)) {
                  _context2.next = 8;
                  break;
                }

                return _context2.abrupt("return", {
                  articles: data.articles
                });

              case 8:
                console.error(data);

                if (response) {
                  response.statusCode = 400;
                  response.end(data.message);
                }

              case 10:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      return function getInitialProps(_x4) {
        return _getInitialProps.apply(this, arguments);
      };
    }()
  }]);

  return News;
}(react__WEBPACK_IMPORTED_MODULE_2___default.a.Component);



/***/ }),

/***/ 4:
/*!*****************************!*\
  !*** multi ./pages/news.js ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./pages/news.js */"./pages/news.js");


/***/ }),

/***/ "@babel/runtime/regenerator":
/*!*********************************************!*\
  !*** external "@babel/runtime/regenerator" ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@babel/runtime/regenerator");

/***/ }),

/***/ "isomorphic-unfetch":
/*!*************************************!*\
  !*** external "isomorphic-unfetch" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("isomorphic-unfetch");

/***/ }),

/***/ "next/link":
/*!****************************!*\
  !*** external "next/link" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/link");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "styled-jsx/style":
/*!***********************************!*\
  !*** external "styled-jsx/style" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("styled-jsx/style");

/***/ })

/******/ });
//# sourceMappingURL=news.js.map