webpackHotUpdate("static\\development\\pages\\news.js",{

/***/ "./pages/news.js":
/*!***********************!*\
  !*** ./pages/news.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return News; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! isomorphic-unfetch */ "./node_modules/isomorphic-unfetch/browser.js");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_SearchForm__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/SearchForm */ "./components/SearchForm.js");

var _jsxFileName = "C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }




var apiKey = '3780066b33ef41b9b4b7e957994e9c38';
var defaultNewsSource = 'the-irish-times';

function getNews(_x) {
  return _getNews.apply(this, arguments);
}

function _getNews() {
  _getNews = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3(url) {
    var res, data;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            _context3.next = 3;
            return isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4___default()(url);

          case 3:
            res = _context3.sent;
            _context3.next = 6;
            return res.json();

          case 6:
            data = _context3.sent;
            return _context3.abrupt("return", data);

          case 10:
            _context3.prev = 10;
            _context3.t0 = _context3["catch"](0);
            return _context3.abrupt("return", _context3.t0);

          case 13:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 10]]);
  }));
  return _getNews.apply(this, arguments);
}

var News =
/*#__PURE__*/
function (_React$Component) {
  _inherits(News, _React$Component);

  function News(props) {
    var _this;

    _classCallCheck(this, News);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(News).call(this, props));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "setNewsSource", function (input) {
      _this.setState({
        newsSource: input,
        url: "https://newsapi.org/v2/top-headlines?sources=".concat(input, "&apiKey=").concat(apiKey)
      });
    });

    _this.state = {
      newsSource: "",
      url: "",
      articles: []
    };
    return _this;
  }

  _createClass(News, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      if (this.state.articles.length == 0) {
        this.state.articles = this.props.articles;
      }

      return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
        className: "jsx-4117342264",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 43
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_components_SearchForm__WEBPACK_IMPORTED_MODULE_5__["default"], {
        setNewsSource: this.setNewsSource,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 44
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("h3", {
        className: "jsx-4117342264",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 45
        },
        __self: this
      }, this.state.newsSource.split("-").join(" ")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
        className: "jsx-4117342264",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 46
        },
        __self: this
      }, this.state.articles.map(function (article, index) {
        return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("section", {
          key: index,
          className: "jsx-4117342264",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 51
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("h3", {
          className: "jsx-4117342264",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 53
          },
          __self: this
        }, article.title), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4117342264" + " " + "author",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 55
          },
          __self: this
        }, article.author, " ", article.publishedAt), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("img", {
          src: article.urlToImage,
          alt: "article image",
          className: "jsx-4117342264" + " " + "img-article",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 57
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4117342264",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 59
          },
          __self: this
        }, article.description), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4117342264",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 61
          },
          __self: this
        }, article.content), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4117342264",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 63
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
          href: "/story",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 63
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
          className: "jsx-4117342264",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 63
          },
          __self: this
        }, "Read More"))), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          onClick: _this2.test,
          className: "jsx-4117342264",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 65
          },
          __self: this
        }, "click.."));
      })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a, {
        styleId: "4117342264",
        css: "section.jsx-4117342264{width:50%;border:1px solid gray;background-color:rgb(240,248,255);padding:1em;margin:1em;}.author.jsx-4117342264{font-style:italic;font-size:0.8em;}.img-article.jsx-4117342264{max-width:50%;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xceDAwMTM2NzA4XFxEb3dubG9hZHNcXHBhZ2VzXFxwYWdlc1xccGFnZXNcXG5ld3MuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBdUVnQixBQUtnQixBQVFRLEFBSUosVUFYUSxJQVl0QixJQUpnQixjQVBvQixFQVFwQyxnQ0FQWSxZQUNELFdBQ1giLCJmaWxlIjoiQzpcXFVzZXJzXFx4MDAxMzY3MDhcXERvd25sb2Fkc1xccGFnZXNcXHBhZ2VzXFxwYWdlc1xcbmV3cy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluayc7XHJcbmltcG9ydCBmZXRjaCBmcm9tICdpc29tb3JwaGljLXVuZmV0Y2gnO1xyXG5pbXBvcnQgU2VhcmNoRm9ybSBmcm9tICcuLi9jb21wb25lbnRzL1NlYXJjaEZvcm0nO1xyXG5jb25zdCBhcGlLZXkgPSAnMzc4MDA2NmIzM2VmNDFiOWI0YjdlOTU3OTk0ZTljMzgnO1xyXG5jb25zdCBkZWZhdWx0TmV3c1NvdXJjZSA9ICd0aGUtaXJpc2gtdGltZXMnXHJcblx0XHRcdFxyXG5hc3luYyBmdW5jdGlvbiBnZXROZXdzKHVybCkge1xyXG50cnkge1xyXG5cdGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCk7XHJcblx0Y29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcblx0cmV0dXJuIChkYXRhKTtcclxufSBjYXRjaCAoZXJyb3IpIHtcclxuXHRyZXR1cm4gKGVycm9yKTtcclxufVxyXG59XHRcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTmV3cyBleHRlbmRzIFJlYWN0LkNvbXBvbmVudCB7XHJcblxyXG5jb25zdHJ1Y3Rvcihwcm9wcykge1xyXG5cdHN1cGVyKHByb3BzKVxyXG5cdHRoaXMuc3RhdGUgPSB7XHJcblx0XHRuZXdzU291cmNlOiBcIlwiLFxyXG5cdFx0dXJsOiBcIlwiLFxyXG5cdFx0YXJ0aWNsZXM6IFtdXHJcblx0fVxyXG59IFxyXG5cclxuc2V0TmV3c1NvdXJjZSA9IChpbnB1dCkgPT4ge1xyXG5cdHRoaXMuc2V0U3RhdGUoe1xyXG5cdFx0bmV3c1NvdXJjZTogaW5wdXQsXHJcblx0XHR1cmw6IGBodHRwczovL25ld3NhcGkub3JnL3YyL3RvcC1oZWFkbGluZXM/c291cmNlcz0ke2lucHV0fSZhcGlLZXk9JHthcGlLZXl9YFxyXG5cdH0pXHJcbn1cclxucmVuZGVyKCkge1xyXG5cclxuXHRpZiAodGhpcy5zdGF0ZS5hcnRpY2xlcy5sZW5ndGggPT0gMCkge1xyXG5cclxuXHRcdHRoaXMuc3RhdGUuYXJ0aWNsZXMgPSB0aGlzLnByb3BzLmFydGljbGVzO1xyXG5cclxuXHR9XHJcblxyXG5cdHJldHVybiAoXHJcblxyXG5cdFx0PGRpdj5cclxuXHRcdDxTZWFyY2hGb3JtIHNldE5ld3NTb3VyY2U9e3RoaXMuc2V0TmV3c1NvdXJjZX0vPlxyXG5cdFx0PGgzPnt0aGlzLnN0YXRlLm5ld3NTb3VyY2Uuc3BsaXQoXCItXCIpLmpvaW4oXCIgXCIpfTwvaDM+XHJcblx0XHRcdDxkaXY+XHJcblxyXG5cclxuXHRcdFx0e3RoaXMuc3RhdGUuYXJ0aWNsZXMubWFwKChhcnRpY2xlLCBpbmRleCkgPT4gKFxyXG5cclxuXHRcdFx0XHQ8c2VjdGlvbiBrZXk9e2luZGV4fT5cclxuXHJcblx0XHRcdFx0PGgzPnthcnRpY2xlLnRpdGxlfTwvaDM+XHJcblxyXG5cdFx0XHRcdDxwIGNsYXNzTmFtZT1cImF1dGhvclwiPnthcnRpY2xlLmF1dGhvcn0ge2FydGljbGUucHVibGlzaGVkQXR9PC9wPlxyXG5cclxuXHRcdFx0XHQ8aW1nIHNyYz17YXJ0aWNsZS51cmxUb0ltYWdlfSBhbHQ9XCJhcnRpY2xlIGltYWdlXCIgY2xhc3NOYW1lPVwiaW1nLWFydGljbGVcIj48L2ltZz5cclxuXHJcblx0XHRcdFx0PHA+e2FydGljbGUuZGVzY3JpcHRpb259PC9wPlxyXG5cclxuXHRcdFx0XHQ8cD57YXJ0aWNsZS5jb250ZW50fTwvcD5cclxuXHJcblx0XHRcdFx0PHA+PExpbmsgaHJlZj1cIi9zdG9yeVwiPjxhPlJlYWQgTW9yZTwvYT48L0xpbms+PC9wPlxyXG5cclxuXHRcdFx0XHQ8cCBvbkNsaWNrPXt0aGlzLnRlc3R9PmNsaWNrLi48L3A+XHJcblxyXG5cdFx0XHRcdDwvc2VjdGlvbj5cclxuXHJcblx0XHRcdCkpfVxyXG5cclxuXHRcdFx0PC9kaXY+XHRcdFxyXG5cdFx0XHRcdDxzdHlsZSBqc3g+e2BcclxuXHJcblxyXG5cdFx0XHRcdFx0c2VjdGlvbiB7XHJcblx0XHRcdFx0XHR3aWR0aDogNTAlO1xyXG5cdFx0XHRcdFx0Ym9yZGVyOiAxcHggc29saWQgZ3JheTtcclxuXHRcdFx0XHRcdGJhY2tncm91bmQtY29sb3I6IHJnYigyNDAsIDI0OCwgMjU1KTtcclxuXHRcdFx0XHRcdHBhZGRpbmc6IDFlbTtcclxuXHRcdFx0XHRcdG1hcmdpbjogMWVtO1xyXG5cdFx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHRcdC5hdXRob3Ige1xyXG5cdFx0XHRcdFx0Zm9udC1zdHlsZTogaXRhbGljO1xyXG5cdFx0XHRcdFx0Zm9udC1zaXplOiAwLjhlbTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdC5pbWctYXJ0aWNsZSB7XHJcblx0XHRcdFx0XHRtYXgtd2lkdGg6IDUwJTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdGB9XHJcblx0XHRcdFx0PC9zdHlsZT5cclxuXHJcblx0XHQ8L2Rpdj5cclxuXHJcblx0KTtcclxuXHJcbn0gXHJcbnN0YXRpYyBhc3luYyBnZXRJbml0aWFsUHJvcHMocmVzcG9uc2UpIHtcclxuXHRjb25zdCBpbml0VXJsID0gYGh0dHBzOi8vbmV3c2FwaS5vcmcvdjIvdG9wLWhlYWRsaW5lcz9zb3VyY2VzPSR7ZGVmYXVsdE5ld3NTb3VyY2V9JmFwaUtleT0ke2FwaUtleX1gO1xyXG5cdGNvbnN0IGRhdGEgPSBhd2FpdCBnZXROZXdzKGluaXRVcmwpO1xyXG5cclxuXHJcblxyXG5cdFx0aWYgKEFycmF5LmlzQXJyYXkoZGF0YS5hcnRpY2xlcykpIHtcclxuXHJcblx0XHRcdHJldHVybiB7XHJcblx0XHRcdFx0YXJ0aWNsZXM6IGRhdGEuYXJ0aWNsZXNcclxuXHJcblx0XHRcdH1cclxuXHJcblx0XHR9XHJcblxyXG5cclxuXHRcdGVsc2Uge1xyXG5cclxuXHRcdFx0Y29uc29sZS5lcnJvcihkYXRhKVxyXG5cclxuXHRcdFx0XHRpZiAocmVzcG9uc2UpIHtcclxuXHJcblx0XHRcdFx0cmVzcG9uc2Uuc3RhdHVzQ29kZSA9IDQwMFxyXG5cclxuXHRcdFx0XHRyZXNwb25zZS5lbmQoZGF0YS5tZXNzYWdlKTtcclxuXHJcblx0XHRcdFx0fVxyXG5cclxuXHRcdH1cclxuXHJcbn1cclxuYXN5bmMgY29tcG9uZW50RGlkVXBkYXRlKHByZXZQcm9wcywgcHJldlN0YXRlKSB7XHJcblxyXG5cclxuaWYgKHRoaXMuc3RhdGUudXJsICE9PSBwcmV2U3RhdGUudXJsKSB7XHJcblxyXG5cclxuY29uc3QgZGF0YSA9IGF3YWl0IGdldE5ld3ModGhpcy5zdGF0ZS51cmwpO1xyXG5cclxuXHJcbmlmIChBcnJheS5pc0FycmF5KGRhdGEuYXJ0aWNsZXMpKSB7XHJcblxyXG5cclxudGhpcy5zdGF0ZS5hcnRpY2xlcyA9IGRhdGEuYXJ0aWNsZXM7XHJcblxyXG5cclxudGhpcy5zZXRTdGF0ZSh0aGlzLnN0YXRlKTtcclxuXHJcbn1cclxuXHJcblxyXG5cclxuZWxzZSB7XHJcblxyXG5jb25zb2xlLmVycm9yKGRhdGEpXHJcblxyXG5pZiAocmVzcG9uc2UpIHtcclxuXHJcbnJlc3BvbnNlLnN0YXR1c0NvZGUgPSA0MDBcclxuXHJcbnJlc3BvbnNlLmVuZChkYXRhLm1lc3NhZ2UpO1xyXG5cclxufVxyXG5cclxufVxyXG5cclxufVxyXG5cclxufSB9XHJcbiJdfQ== */\n/*@ sourceURL=C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js */",
        __self: this
      }));
    }
  }, {
    key: "componentDidUpdate",
    value: function () {
      var _componentDidUpdate = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(prevProps, prevState) {
        var data;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!(this.state.url !== prevState.url)) {
                  _context.next = 5;
                  break;
                }

                _context.next = 3;
                return getNews(this.state.url);

              case 3:
                data = _context.sent;

                if (Array.isArray(data.articles)) {
                  this.state.articles = data.articles;
                  this.setState(this.state);
                } else {
                  console.error(data);

                  if (response) {
                    response.statusCode = 400;
                    response.end(data.message);
                  }
                }

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      return function componentDidUpdate(_x2, _x3) {
        return _componentDidUpdate.apply(this, arguments);
      };
    }()
  }], [{
    key: "getInitialProps",
    value: function () {
      var _getInitialProps = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(response) {
        var initUrl, data;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                initUrl = "https://newsapi.org/v2/top-headlines?sources=".concat(defaultNewsSource, "&apiKey=").concat(apiKey);
                _context2.next = 3;
                return getNews(initUrl);

              case 3:
                data = _context2.sent;

                if (!Array.isArray(data.articles)) {
                  _context2.next = 8;
                  break;
                }

                return _context2.abrupt("return", {
                  articles: data.articles
                });

              case 8:
                console.error(data);

                if (response) {
                  response.statusCode = 400;
                  response.end(data.message);
                }

              case 10:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      return function getInitialProps(_x4) {
        return _getInitialProps.apply(this, arguments);
      };
    }()
  }]);

  return News;
}(react__WEBPACK_IMPORTED_MODULE_2___default.a.Component);


    (function (Component, route) {
      if(!Component) return
      if (false) {}
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/news")
  
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=news.js.b87f3fa423b2bfd09c3d.hot-update.js.map