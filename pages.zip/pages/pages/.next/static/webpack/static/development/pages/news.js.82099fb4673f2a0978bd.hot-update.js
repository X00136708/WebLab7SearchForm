webpackHotUpdate("static\\development\\pages\\news.js",{

/***/ "./pages/news.js":
/*!***********************!*\
  !*** ./pages/news.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return News; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! isomorphic-unfetch */ "./node_modules/isomorphic-unfetch/browser.js");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_SearchForm__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/SearchForm */ "./components/SearchForm.js");

var _jsxFileName = "C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

 // Import fetch library

 // mport SearchForm Component

 //(free version) API key from https://newsapi.org/
// Get your own key!

var apiKey = '3780066b33ef41b9b4b7e957994e9c38'; // Initial News source

var defaultNewsSource = 'the-irish-times';

function getNews(_x) {
  return _getNews.apply(this, arguments);
}

function _getNews() {
  _getNews = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(url) {
    var res, data;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            _context2.next = 3;
            return isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4___default()(url);

          case 3:
            res = _context2.sent;
            _context2.next = 6;
            return res.json();

          case 6:
            data = _context2.sent;
            return _context2.abrupt("return", data);

          case 10:
            _context2.prev = 10;
            _context2.t0 = _context2["catch"](0);
            return _context2.abrupt("return", _context2.t0);

          case 13:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 10]]);
  }));
  return _getNews.apply(this, arguments);
}

var News =
/*#__PURE__*/
function (_React$Component) {
  _inherits(News, _React$Component);

  // Constructor
  // Recieve props and initialise state properties
  //
  function News(props) {
    var _this;

    _classCallCheck(this, News);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(News).call(this, props));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "setNewsSource", function (input) {
      _this.setState({
        newsSource: input,
        url: "https://newsapi.org/v2/top-headlines?sources=".concat(input, "&apiKey=").concat(apiKey)
      });
    });

    _this.state = {
      newsSource: "",
      url: "",
      articles: []
    };
    return _this;
  } //end Constructor
  //
  // render() method generates the page
  //


  _createClass(News, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      // if state.articles is empty copy props to it
      if (this.state.articles.length == 0) {
        this.state.articles = this.props.articles;
      }

      return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
        className: "jsx-4285934496",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 95
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_components_SearchForm__WEBPACK_IMPORTED_MODULE_5__["default"], {
        setNewsSource: this.setNewsSource,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 96
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("h3", {
        className: "jsx-4285934496",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 99
        },
        __self: this
      }, this.state.newsSource.split("-").join(" ")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
        className: "jsx-4285934496",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 101
        },
        __self: this
      }, this.state.articles.map(function (article, index) {
        return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("section", {
          key: index,
          className: "jsx-4285934496",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 111
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("h3", {
          className: "jsx-4285934496",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 113
          },
          __self: this
        }, article.title), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4285934496" + " " + "author",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 115
          },
          __self: this
        }, article.author, " ", article.publishedAt), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("img", {
          src: article.urlToImage,
          alt: "article image",
          className: "jsx-4285934496" + " " + "img-article",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 117
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4285934496",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 119
          },
          __self: this
        }, article.description), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4285934496",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 121
          },
          __self: this
        }, article.content), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4285934496",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 123
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
          href: "/story",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 123
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
          className: "jsx-4285934496",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 123
          },
          __self: this
        }, "Read More"))), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          onClick: _this2.test,
          className: "jsx-4285934496",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 125
          },
          __self: this
        }, "click.."));
      })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a, {
        styleId: "4285934496",
        css: "section.jsx-4285934496{width:50%;border:1px solid gray;background-color:rgb(240,248,255);padding:1em;margin:1em;}.author.jsx-4285934496{font-style:italic;font-size:0.8em;}.img-article.jsx-4285934496{max-width:50%;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xceDAwMTM2NzA4XFxEb3dubG9hZHNcXHBhZ2VzXFxwYWdlc1xccGFnZXNcXG5ld3MuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBbUlZLEFBT1csQUFjUSxBQVFKLFVBcEJRLElBc0J0QixJQVJnQixjQVpvQixFQWNwQyxnQ0FaWSxZQUVELFdBRVgiLCJmaWxlIjoiQzpcXFVzZXJzXFx4MDAxMzY3MDhcXERvd25sb2Fkc1xccGFnZXNcXHBhZ2VzXFxwYWdlc1xcbmV3cy5qcyIsInNvdXJjZXNDb250ZW50IjpbIlx0aW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcclxuXHJcbi8vIEltcG9ydCBmZXRjaCBsaWJyYXJ5XHJcblxyXG5pbXBvcnQgZmV0Y2ggZnJvbSAnaXNvbW9ycGhpYy11bmZldGNoJztcclxuXHJcbi8vIG1wb3J0IFNlYXJjaEZvcm0gQ29tcG9uZW50XHJcblxyXG5pbXBvcnQgU2VhcmNoRm9ybSBmcm9tICcuLi9jb21wb25lbnRzL1NlYXJjaEZvcm0nO1xyXG5cclxuLy8oZnJlZSB2ZXJzaW9uKSBBUEkga2V5IGZyb20gaHR0cHM6Ly9uZXdzYXBpLm9yZy9cclxuXHJcbi8vIEdldCB5b3VyIG93biBrZXkhXHJcblxyXG5jb25zdCBhcGlLZXkgPSAnMzc4MDA2NmIzM2VmNDFiOWI0YjdlOTU3OTk0ZTljMzgnO1xyXG5cclxuLy8gSW5pdGlhbCBOZXdzIHNvdXJjZVxyXG5cclxuY29uc3QgZGVmYXVsdE5ld3NTb3VyY2UgPSAndGhlLWlyaXNoLXRpbWVzJ1xyXG5cdFx0XHRcclxuYXN5bmMgZnVuY3Rpb24gZ2V0TmV3cyh1cmwpIHtcclxuXHJcbi8vIHRyeSBmZXRjaCBhbmQgY2F0Y2ggYW55IGVycm9yc1xyXG5cclxudHJ5IHtcclxuXHJcbi8vIE1ha2UgYXN5bmMgY2FsbFxyXG5cclxuY29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsKTtcclxuXHJcbi8vIGdldCBqc29uIGRhdGEgd2hlbiBpdCBhcnJpdmVzXHJcblxyXG5jb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuXHJcbi8vIHJldHVybiBqc29uIGRhdGFcclxuXHJcbnJldHVybiAoZGF0YSk7XHJcblxyXG59IGNhdGNoIChlcnJvcikge1xyXG5cclxuLy8gcmV0dXJuIGVycm9yIGlmIGl0IG9jY3Vyc1xyXG5cclxucmV0dXJuIChlcnJvcik7XHJcblxyXG59XHJcblxyXG59XHRcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTmV3cyBleHRlbmRzIFJlYWN0LkNvbXBvbmVudCB7XHJcblxyXG4vLyBDb25zdHJ1Y3RvclxyXG5cclxuLy8gUmVjaWV2ZSBwcm9wcyBhbmQgaW5pdGlhbGlzZSBzdGF0ZSBwcm9wZXJ0aWVzXHJcblxyXG4vL1xyXG5cclxuY29uc3RydWN0b3IocHJvcHMpIHtcclxuXHJcbnN1cGVyKHByb3BzKVxyXG5cclxudGhpcy5zdGF0ZSA9IHtcclxuXHJcbm5ld3NTb3VyY2U6IFwiXCIsXHJcblxyXG51cmw6IFwiXCIsXHJcblxyXG5hcnRpY2xlczogW11cclxuXHJcbn1cclxuXHJcbn0gLy9lbmQgQ29uc3RydWN0b3JcclxuXHJcbi8vXHJcblxyXG4vLyByZW5kZXIoKSBtZXRob2QgZ2VuZXJhdGVzIHRoZSBwYWdlXHJcblxyXG4vL1xyXG5zZXROZXdzU291cmNlID0gKGlucHV0KSA9PiB7XHJcblx0dGhpcy5zZXRTdGF0ZSh7XHJcblx0XHRuZXdzU291cmNlOiBpbnB1dCxcclxuXHRcdHVybDogYGh0dHBzOi8vbmV3c2FwaS5vcmcvdjIvdG9wLWhlYWRsaW5lcz9zb3VyY2VzPSR7aW5wdXR9JmFwaUtleT0ke2FwaUtleX1gXHJcblx0fSlcclxufVxyXG5yZW5kZXIoKSB7XHJcblxyXG4vLyBpZiBzdGF0ZS5hcnRpY2xlcyBpcyBlbXB0eSBjb3B5IHByb3BzIHRvIGl0XHJcblxyXG5pZiAodGhpcy5zdGF0ZS5hcnRpY2xlcy5sZW5ndGggPT0gMCkge1xyXG5cclxudGhpcy5zdGF0ZS5hcnRpY2xlcyA9IHRoaXMucHJvcHMuYXJ0aWNsZXM7XHJcblxyXG59XHJcblxyXG5yZXR1cm4gKFxyXG5cclxuPGRpdj5cclxuPFNlYXJjaEZvcm0gc2V0TmV3c1NvdXJjZT17dGhpcy5zZXROZXdzU291cmNlfS8+XHJcbnsgLyogRGlzcGxheSBhIHRpdGxlIGJhc2VkIG9uIHNvdXJjZSAqL31cclxuXHJcbjxoMz57dGhpcy5zdGF0ZS5uZXdzU291cmNlLnNwbGl0KFwiLVwiKS5qb2luKFwiIFwiKX08L2gzPlxyXG5cclxuPGRpdj5cclxuXHJcbnsgLyogSXRlcmF0ZSB0aHJvdWdoIGFydGljbGVzIHVzaW5nIEFycmF5IG1hcCkgKi99XHJcblxyXG57IC8qIERpc3BsYXkgYXV0aG9yLCBwdWJsaXNoZWRBdCwgaW1hZ2UsIGRlc2NyaXB0aW9uLCBhbmQgY29udGVudCAqL31cclxuXHJcbnsgLyogZm9yIGVhY2ggc3RvcnkuIEFsc28gYSBsaW5rIGZvciBtb3JlLi4gKi99XHJcblxyXG57dGhpcy5zdGF0ZS5hcnRpY2xlcy5tYXAoKGFydGljbGUsIGluZGV4KSA9PiAoXHJcblxyXG48c2VjdGlvbiBrZXk9e2luZGV4fT5cclxuXHJcbjxoMz57YXJ0aWNsZS50aXRsZX08L2gzPlxyXG5cclxuPHAgY2xhc3NOYW1lPVwiYXV0aG9yXCI+e2FydGljbGUuYXV0aG9yfSB7YXJ0aWNsZS5wdWJsaXNoZWRBdH08L3A+XHJcblxyXG48aW1nIHNyYz17YXJ0aWNsZS51cmxUb0ltYWdlfSBhbHQ9XCJhcnRpY2xlIGltYWdlXCIgY2xhc3NOYW1lPVwiaW1nLWFydGljbGVcIj48L2ltZz5cclxuXHJcbjxwPnthcnRpY2xlLmRlc2NyaXB0aW9ufTwvcD5cclxuXHJcbjxwPnthcnRpY2xlLmNvbnRlbnR9PC9wPlxyXG5cclxuPHA+PExpbmsgaHJlZj1cIi9zdG9yeVwiPjxhPlJlYWQgTW9yZTwvYT48L0xpbms+PC9wPlxyXG5cclxuPHAgb25DbGljaz17dGhpcy50ZXN0fT5jbGljay4uPC9wPlxyXG5cclxuPC9zZWN0aW9uPlxyXG5cclxuKSl9XHJcblxyXG48L2Rpdj5cdFx0XHJcbjxzdHlsZSBqc3g+e2BcclxuXHJcbi8qIENTUyBmb3IgdGhpcyBwYWdlICovXHJcblxyXG5zZWN0aW9uIHtcclxuXHJcbndpZHRoOiA1MCU7XHJcblxyXG5ib3JkZXI6IDFweCBzb2xpZCBncmF5O1xyXG5cclxuYmFja2dyb3VuZC1jb2xvcjogcmdiKDI0MCwgMjQ4LCAyNTUpO1xyXG5cclxucGFkZGluZzogMWVtO1xyXG5cclxubWFyZ2luOiAxZW07XHJcblxyXG59XHJcblxyXG4uYXV0aG9yIHtcclxuXHJcbmZvbnQtc3R5bGU6IGl0YWxpYztcclxuXHJcbmZvbnQtc2l6ZTogMC44ZW07XHJcblxyXG59XHJcblxyXG4uaW1nLWFydGljbGUge1xyXG5cclxubWF4LXdpZHRoOiA1MCU7XHJcblxyXG59XHJcblxyXG5gfTwvc3R5bGU+XHJcblxyXG48L2Rpdj5cclxuXHJcbik7XHJcblxyXG59IC8vIEVuZCByZW5kZXIoKVxyXG5zdGF0aWMgYXN5bmMgZ2V0SW5pdGlhbFByb3BzKHJlc3BvbnNlKSB7XHJcblxyXG4vLyBCdWlsZCB0aGUgdXJsIHdoaWNoIHdpbGwgYmUgdXNlZCB0byBnZXQgdGhlIGRhdGFcclxuXHJcbi8vIFNlZSBodHRwczovL25ld3NhcGkub3JnL3MvdGhlLWlyaXNoLXRpbWVzLWFwaVxyXG5cclxuY29uc3QgaW5pdFVybCA9IGBodHRwczovL25ld3NhcGkub3JnL3YyL3RvcC1oZWFkbGluZXM/c291cmNlcz0ke2RlZmF1bHROZXdzU291cmNlfSZhcGlLZXk9JHthcGlLZXl9YDtcclxuXHJcbi8vIEdldCBuZXdzIGRhdGEgZnJvbSB0aGUgYXBpIHVybFxyXG5cclxuY29uc3QgZGF0YSA9IGF3YWl0IGdldE5ld3MoaW5pdFVybCk7XHJcblxyXG4vLyBJZiB0aGUgcmVzdWx0IGNvbnRhaW5zIGFuZCBhcnRpY2xlcyBhcnJheSB0aGVuIGl0IGlzIGdvb2Qgc28gcmV0dXJuIGFydGljbGVzXHJcblxyXG5pZiAoQXJyYXkuaXNBcnJheShkYXRhLmFydGljbGVzKSkge1xyXG5cclxucmV0dXJuIHtcclxuXHJcbmFydGljbGVzOiBkYXRhLmFydGljbGVzXHJcblxyXG59XHJcblxyXG59XHJcblxyXG4vLyBPdGhlcndpc2UgaXQgY29udGFpbnMgYW4gZXJyb3IsIGxvZyBhbmQgcmVkaXJlY3QgdG8gZXJyb3IgcGFnZSAoc3RhdHVzIGNvZGUgNDAwKVxyXG5cclxuZWxzZSB7XHJcblxyXG5jb25zb2xlLmVycm9yKGRhdGEpXHJcblxyXG5pZiAocmVzcG9uc2UpIHtcclxuXHJcbnJlc3BvbnNlLnN0YXR1c0NvZGUgPSA0MDBcclxuXHJcbnJlc3BvbnNlLmVuZChkYXRhLm1lc3NhZ2UpO1xyXG5cclxufVxyXG5cclxufVxyXG5cclxufX1cclxuIl19 */\n/*@ sourceURL=C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js */",
        __self: this
      }));
    } // End render()

  }], [{
    key: "getInitialProps",
    value: function () {
      var _getInitialProps = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(response) {
        var initUrl, data;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                // Build the url which will be used to get the data
                // See https://newsapi.org/s/the-irish-times-api
                initUrl = "https://newsapi.org/v2/top-headlines?sources=".concat(defaultNewsSource, "&apiKey=").concat(apiKey); // Get news data from the api url

                _context.next = 3;
                return getNews(initUrl);

              case 3:
                data = _context.sent;

                if (!Array.isArray(data.articles)) {
                  _context.next = 8;
                  break;
                }

                return _context.abrupt("return", {
                  articles: data.articles
                });

              case 8:
                console.error(data);

                if (response) {
                  response.statusCode = 400;
                  response.end(data.message);
                }

              case 10:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      return function getInitialProps(_x2) {
        return _getInitialProps.apply(this, arguments);
      };
    }()
  }]);

  return News;
}(react__WEBPACK_IMPORTED_MODULE_2___default.a.Component);


    (function (Component, route) {
      if(!Component) return
      if (false) {}
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/news")
  
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=news.js.82099fb4673f2a0978bd.hot-update.js.map