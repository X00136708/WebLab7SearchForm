webpackHotUpdate("static\\development\\pages\\news.js",{

/***/ "./pages/news.js":
/*!***********************!*\
  !*** ./pages/news.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return News; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! isomorphic-unfetch */ "./node_modules/isomorphic-unfetch/browser.js");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_SearchForm__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/SearchForm */ "./components/SearchForm.js");

var _jsxFileName = "C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

 // Import fetch library

 // mport SearchForm Component

 //(free version) API key from https://newsapi.org/
// Get your own key!

var apiKey = '3780066b33ef41b9b4b7e957994e9c38'; // Initial News source

var defaultNewsSource = 'the-irish-times';

function getNews(_x) {
  return _getNews.apply(this, arguments);
}

function _getNews() {
  _getNews = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(url) {
    var res, data;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            _context2.next = 3;
            return isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4___default()(url);

          case 3:
            res = _context2.sent;
            _context2.next = 6;
            return res.json();

          case 6:
            data = _context2.sent;
            return _context2.abrupt("return", data);

          case 10:
            _context2.prev = 10;
            _context2.t0 = _context2["catch"](0);
            return _context2.abrupt("return", _context2.t0);

          case 13:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 10]]);
  }));
  return _getNews.apply(this, arguments);
}

var News =
/*#__PURE__*/
function (_React$Component) {
  _inherits(News, _React$Component);

  // Constructor
  // Recieve props and initialise state properties
  //
  function News(props) {
    var _this;

    _classCallCheck(this, News);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(News).call(this, props));
    _this.state = {
      newsSource: "",
      url: "",
      articles: []
    };
    return _this;
  } //end Constructor
  //
  // render() method generates the page
  //


  _createClass(News, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      // if state.articles is empty copy props to it
      if (this.state.articles.length == 0) {
        this.state.articles = this.props.articles;
      }

      return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
        className: "jsx-4285934496",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 90
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("h3", {
        className: "jsx-4285934496",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 94
        },
        __self: this
      }, this.state.newsSource.split("-").join(" ")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
        className: "jsx-4285934496",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 96
        },
        __self: this
      }, this.state.articles.map(function (article, index) {
        return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("section", {
          key: index,
          className: "jsx-4285934496",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 106
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("h3", {
          className: "jsx-4285934496",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 108
          },
          __self: this
        }, article.title), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4285934496" + " " + "author",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 110
          },
          __self: this
        }, article.author, " ", article.publishedAt), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("img", {
          src: article.urlToImage,
          alt: "article image",
          className: "jsx-4285934496" + " " + "img-article",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 112
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4285934496",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 114
          },
          __self: this
        }, article.description), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4285934496",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 116
          },
          __self: this
        }, article.content), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4285934496",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 118
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
          href: "/story",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 118
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
          className: "jsx-4285934496",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 118
          },
          __self: this
        }, "Read More"))), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          onClick: _this2.test,
          className: "jsx-4285934496",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 120
          },
          __self: this
        }, "click.."));
      })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a, {
        styleId: "4285934496",
        css: "section.jsx-4285934496{width:50%;border:1px solid gray;background-color:rgb(240,248,255);padding:1em;margin:1em;}.author.jsx-4285934496{font-style:italic;font-size:0.8em;}.img-article.jsx-4285934496{max-width:50%;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xceDAwMTM2NzA4XFxEb3dubG9hZHNcXHBhZ2VzXFxwYWdlc1xccGFnZXNcXG5ld3MuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBOEhZLEFBT1csQUFjUSxBQVFKLFVBcEJRLElBc0J0QixJQVJnQixjQVpvQixFQWNwQyxnQ0FaWSxZQUVELFdBRVgiLCJmaWxlIjoiQzpcXFVzZXJzXFx4MDAxMzY3MDhcXERvd25sb2Fkc1xccGFnZXNcXHBhZ2VzXFxwYWdlc1xcbmV3cy5qcyIsInNvdXJjZXNDb250ZW50IjpbIlx0aW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcclxuXHJcbi8vIEltcG9ydCBmZXRjaCBsaWJyYXJ5XHJcblxyXG5pbXBvcnQgZmV0Y2ggZnJvbSAnaXNvbW9ycGhpYy11bmZldGNoJztcclxuXHJcbi8vIG1wb3J0IFNlYXJjaEZvcm0gQ29tcG9uZW50XHJcblxyXG5pbXBvcnQgU2VhcmNoRm9ybSBmcm9tICcuLi9jb21wb25lbnRzL1NlYXJjaEZvcm0nO1xyXG5cclxuLy8oZnJlZSB2ZXJzaW9uKSBBUEkga2V5IGZyb20gaHR0cHM6Ly9uZXdzYXBpLm9yZy9cclxuXHJcbi8vIEdldCB5b3VyIG93biBrZXkhXHJcblxyXG5jb25zdCBhcGlLZXkgPSAnMzc4MDA2NmIzM2VmNDFiOWI0YjdlOTU3OTk0ZTljMzgnO1xyXG5cclxuLy8gSW5pdGlhbCBOZXdzIHNvdXJjZVxyXG5cclxuY29uc3QgZGVmYXVsdE5ld3NTb3VyY2UgPSAndGhlLWlyaXNoLXRpbWVzJ1xyXG5cdFx0XHRcclxuYXN5bmMgZnVuY3Rpb24gZ2V0TmV3cyh1cmwpIHtcclxuXHJcbi8vIHRyeSBmZXRjaCBhbmQgY2F0Y2ggYW55IGVycm9yc1xyXG5cclxudHJ5IHtcclxuXHJcbi8vIE1ha2UgYXN5bmMgY2FsbFxyXG5cclxuY29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsKTtcclxuXHJcbi8vIGdldCBqc29uIGRhdGEgd2hlbiBpdCBhcnJpdmVzXHJcblxyXG5jb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuXHJcbi8vIHJldHVybiBqc29uIGRhdGFcclxuXHJcbnJldHVybiAoZGF0YSk7XHJcblxyXG59IGNhdGNoIChlcnJvcikge1xyXG5cclxuLy8gcmV0dXJuIGVycm9yIGlmIGl0IG9jY3Vyc1xyXG5cclxucmV0dXJuIChlcnJvcik7XHJcblxyXG59XHJcblxyXG59XHRcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTmV3cyBleHRlbmRzIFJlYWN0LkNvbXBvbmVudCB7XHJcblxyXG4vLyBDb25zdHJ1Y3RvclxyXG5cclxuLy8gUmVjaWV2ZSBwcm9wcyBhbmQgaW5pdGlhbGlzZSBzdGF0ZSBwcm9wZXJ0aWVzXHJcblxyXG4vL1xyXG5cclxuY29uc3RydWN0b3IocHJvcHMpIHtcclxuXHJcbnN1cGVyKHByb3BzKVxyXG5cclxudGhpcy5zdGF0ZSA9IHtcclxuXHJcbm5ld3NTb3VyY2U6IFwiXCIsXHJcblxyXG51cmw6IFwiXCIsXHJcblxyXG5hcnRpY2xlczogW11cclxuXHJcbn1cclxuXHJcbn0gLy9lbmQgQ29uc3RydWN0b3JcclxuXHJcbi8vXHJcblxyXG4vLyByZW5kZXIoKSBtZXRob2QgZ2VuZXJhdGVzIHRoZSBwYWdlXHJcblxyXG4vL1xyXG5cclxucmVuZGVyKCkge1xyXG5cclxuLy8gaWYgc3RhdGUuYXJ0aWNsZXMgaXMgZW1wdHkgY29weSBwcm9wcyB0byBpdFxyXG5cclxuaWYgKHRoaXMuc3RhdGUuYXJ0aWNsZXMubGVuZ3RoID09IDApIHtcclxuXHJcbnRoaXMuc3RhdGUuYXJ0aWNsZXMgPSB0aGlzLnByb3BzLmFydGljbGVzO1xyXG5cclxufVxyXG5cclxucmV0dXJuIChcclxuXHJcbjxkaXY+XHJcblxyXG57IC8qIERpc3BsYXkgYSB0aXRsZSBiYXNlZCBvbiBzb3VyY2UgKi99XHJcblxyXG48aDM+e3RoaXMuc3RhdGUubmV3c1NvdXJjZS5zcGxpdChcIi1cIikuam9pbihcIiBcIil9PC9oMz5cclxuXHJcbjxkaXY+XHJcblxyXG57IC8qIEl0ZXJhdGUgdGhyb3VnaCBhcnRpY2xlcyB1c2luZyBBcnJheSBtYXApICovfVxyXG5cclxueyAvKiBEaXNwbGF5IGF1dGhvciwgcHVibGlzaGVkQXQsIGltYWdlLCBkZXNjcmlwdGlvbiwgYW5kIGNvbnRlbnQgKi99XHJcblxyXG57IC8qIGZvciBlYWNoIHN0b3J5LiBBbHNvIGEgbGluayBmb3IgbW9yZS4uICovfVxyXG5cclxue3RoaXMuc3RhdGUuYXJ0aWNsZXMubWFwKChhcnRpY2xlLCBpbmRleCkgPT4gKFxyXG5cclxuPHNlY3Rpb24ga2V5PXtpbmRleH0+XHJcblxyXG48aDM+e2FydGljbGUudGl0bGV9PC9oMz5cclxuXHJcbjxwIGNsYXNzTmFtZT1cImF1dGhvclwiPnthcnRpY2xlLmF1dGhvcn0ge2FydGljbGUucHVibGlzaGVkQXR9PC9wPlxyXG5cclxuPGltZyBzcmM9e2FydGljbGUudXJsVG9JbWFnZX0gYWx0PVwiYXJ0aWNsZSBpbWFnZVwiIGNsYXNzTmFtZT1cImltZy1hcnRpY2xlXCI+PC9pbWc+XHJcblxyXG48cD57YXJ0aWNsZS5kZXNjcmlwdGlvbn08L3A+XHJcblxyXG48cD57YXJ0aWNsZS5jb250ZW50fTwvcD5cclxuXHJcbjxwPjxMaW5rIGhyZWY9XCIvc3RvcnlcIj48YT5SZWFkIE1vcmU8L2E+PC9MaW5rPjwvcD5cclxuXHJcbjxwIG9uQ2xpY2s9e3RoaXMudGVzdH0+Y2xpY2suLjwvcD5cclxuXHJcbjwvc2VjdGlvbj5cclxuXHJcbikpfVxyXG5cclxuPC9kaXY+XHRcdFxyXG48c3R5bGUganN4PntgXHJcblxyXG4vKiBDU1MgZm9yIHRoaXMgcGFnZSAqL1xyXG5cclxuc2VjdGlvbiB7XHJcblxyXG53aWR0aDogNTAlO1xyXG5cclxuYm9yZGVyOiAxcHggc29saWQgZ3JheTtcclxuXHJcbmJhY2tncm91bmQtY29sb3I6IHJnYigyNDAsIDI0OCwgMjU1KTtcclxuXHJcbnBhZGRpbmc6IDFlbTtcclxuXHJcbm1hcmdpbjogMWVtO1xyXG5cclxufVxyXG5cclxuLmF1dGhvciB7XHJcblxyXG5mb250LXN0eWxlOiBpdGFsaWM7XHJcblxyXG5mb250LXNpemU6IDAuOGVtO1xyXG5cclxufVxyXG5cclxuLmltZy1hcnRpY2xlIHtcclxuXHJcbm1heC13aWR0aDogNTAlO1xyXG5cclxufVxyXG5cclxuYH08L3N0eWxlPlxyXG5cclxuPC9kaXY+XHJcblxyXG4pO1xyXG5cclxufSAvLyBFbmQgcmVuZGVyKClcclxuc3RhdGljIGFzeW5jIGdldEluaXRpYWxQcm9wcyhyZXNwb25zZSkge1xyXG5cclxuLy8gQnVpbGQgdGhlIHVybCB3aGljaCB3aWxsIGJlIHVzZWQgdG8gZ2V0IHRoZSBkYXRhXHJcblxyXG4vLyBTZWUgaHR0cHM6Ly9uZXdzYXBpLm9yZy9zL3RoZS1pcmlzaC10aW1lcy1hcGlcclxuXHJcbmNvbnN0IGluaXRVcmwgPSBgaHR0cHM6Ly9uZXdzYXBpLm9yZy92Mi90b3AtaGVhZGxpbmVzP3NvdXJjZXM9JHtkZWZhdWx0TmV3c1NvdXJjZX0mYXBpS2V5PSR7YXBpS2V5fWA7XHJcblxyXG4vLyBHZXQgbmV3cyBkYXRhIGZyb20gdGhlIGFwaSB1cmxcclxuXHJcbmNvbnN0IGRhdGEgPSBhd2FpdCBnZXROZXdzKGluaXRVcmwpO1xyXG5cclxuLy8gSWYgdGhlIHJlc3VsdCBjb250YWlucyBhbmQgYXJ0aWNsZXMgYXJyYXkgdGhlbiBpdCBpcyBnb29kIHNvIHJldHVybiBhcnRpY2xlc1xyXG5cclxuaWYgKEFycmF5LmlzQXJyYXkoZGF0YS5hcnRpY2xlcykpIHtcclxuXHJcbnJldHVybiB7XHJcblxyXG5hcnRpY2xlczogZGF0YS5hcnRpY2xlc1xyXG5cclxufVxyXG5cclxufVxyXG5cclxuLy8gT3RoZXJ3aXNlIGl0IGNvbnRhaW5zIGFuIGVycm9yLCBsb2cgYW5kIHJlZGlyZWN0IHRvIGVycm9yIHBhZ2UgKHN0YXR1cyBjb2RlIDQwMClcclxuXHJcbmVsc2Uge1xyXG5cclxuY29uc29sZS5lcnJvcihkYXRhKVxyXG5cclxuaWYgKHJlc3BvbnNlKSB7XHJcblxyXG5yZXNwb25zZS5zdGF0dXNDb2RlID0gNDAwXHJcblxyXG5yZXNwb25zZS5lbmQoZGF0YS5tZXNzYWdlKTtcclxuXHJcbn1cclxuXHJcbn1cclxuXHJcbn19XHJcbiJdfQ== */\n/*@ sourceURL=C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js */",
        __self: this
      }));
    } // End render()

  }], [{
    key: "getInitialProps",
    value: function () {
      var _getInitialProps = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(response) {
        var initUrl, data;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                // Build the url which will be used to get the data
                // See https://newsapi.org/s/the-irish-times-api
                initUrl = "https://newsapi.org/v2/top-headlines?sources=".concat(defaultNewsSource, "&apiKey=").concat(apiKey); // Get news data from the api url

                _context.next = 3;
                return getNews(initUrl);

              case 3:
                data = _context.sent;

                if (!Array.isArray(data.articles)) {
                  _context.next = 8;
                  break;
                }

                return _context.abrupt("return", {
                  articles: data.articles
                });

              case 8:
                console.error(data);

                if (response) {
                  response.statusCode = 400;
                  response.end(data.message);
                }

              case 10:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      return function getInitialProps(_x2) {
        return _getInitialProps.apply(this, arguments);
      };
    }()
  }]);

  return News;
}(react__WEBPACK_IMPORTED_MODULE_2___default.a.Component);


    (function (Component, route) {
      if(!Component) return
      if (false) {}
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/news")
  
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=news.js.54e212292b7d173f18de.hot-update.js.map