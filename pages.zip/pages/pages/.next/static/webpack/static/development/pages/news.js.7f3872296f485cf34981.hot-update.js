webpackHotUpdate("static\\development\\pages\\news.js",{

/***/ "./pages/news.js":
/*!***********************!*\
  !*** ./pages/news.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return News; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! isomorphic-unfetch */ "./node_modules/isomorphic-unfetch/browser.js");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_SearchForm__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/SearchForm */ "./components/SearchForm.js");

var _jsxFileName = "C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }




var apiKey = '3780066b33ef41b9b4b7e957994e9c38';
var defaultNewsSource = 'the-irish-times';

function getNews(_x) {
  return _getNews.apply(this, arguments);
}

function _getNews() {
  _getNews = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3(url) {
    var res, data;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            _context3.next = 3;
            return isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4___default()(url);

          case 3:
            res = _context3.sent;
            _context3.next = 6;
            return res.json();

          case 6:
            data = _context3.sent;
            return _context3.abrupt("return", data);

          case 10:
            _context3.prev = 10;
            _context3.t0 = _context3["catch"](0);
            return _context3.abrupt("return", _context3.t0);

          case 13:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 10]]);
  }));
  return _getNews.apply(this, arguments);
}

var News =
/*#__PURE__*/
function (_React$Component) {
  _inherits(News, _React$Component);

  function News(props) {
    var _this;

    _classCallCheck(this, News);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(News).call(this, props));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "setNewsSource", function (input) {
      _this.setState({
        newsSource: input,
        url: "https://newsapi.org/v2/top-headlines?sources=".concat(input, "&apiKey=").concat(apiKey)
      });
    });

    _this.state = {
      newsSource: "",
      url: "",
      articles: []
    };
    return _this;
  }

  _createClass(News, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      if (this.state.articles.length == 0) {
        this.state.articles = this.props.articles;
      }

      return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
        className: "jsx-2131122053",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 43
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_components_SearchForm__WEBPACK_IMPORTED_MODULE_5__["default"], {
        setNewsSource: this.setNewsSource,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 44
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("ul", {
        className: "jsx-2131122053" + " " + "newsMenu",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 47
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("li", {
        className: "jsx-2131122053",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 48
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
        href: "a",
        onClick: this.searchNewsAPI,
        name: "top-headlines?country=ie",
        className: "jsx-2131122053",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 48
        },
        __self: this
      }, "Top Headlines Ireland")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("li", {
        className: "jsx-2131122053",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 49
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
        href: "a",
        onClick: this.searchNewsAPI,
        name: "top-headlines?country=ie&category=business",
        className: "jsx-2131122053",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 49
        },
        __self: this
      }, "Business News Ireland")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("li", {
        className: "jsx-2131122053",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 50
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
        href: "a",
        onClick: this.searchNewsAPI,
        name: "everything?q=technology",
        className: "jsx-2131122053",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 50
        },
        __self: this
      }, "Technology News")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("li", {
        className: "jsx-2131122053",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 51
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
        href: "a",
        onClick: this.searchNewsAPI,
        name: "top-headlines?country=ie&category=weather",
        className: "jsx-2131122053",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 51
        },
        __self: this
      }, "Weather in Ireland"))), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("h3", {
        className: "jsx-2131122053",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 54
        },
        __self: this
      }, this.state.newsSource.split("-").join(" ")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
        className: "jsx-2131122053",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 55
        },
        __self: this
      }, this.state.articles.map(function (article, index) {
        return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("section", {
          key: index,
          className: "jsx-2131122053",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 59
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("h3", {
          className: "jsx-2131122053",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 60
          },
          __self: this
        }, article.title), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-2131122053" + " " + "author",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 61
          },
          __self: this
        }, article.author, " ", article.publishedAt), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("img", {
          src: article.urlToImage,
          alt: "article image",
          className: "jsx-2131122053" + " " + "img-article",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 62
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-2131122053",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 63
          },
          __self: this
        }, article.description), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-2131122053",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 64
          },
          __self: this
        }, article.content), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-2131122053",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 65
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
          href: "/story",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 65
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
          className: "jsx-2131122053",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 65
          },
          __self: this
        }, "Read More"))), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          onClick: _this2.test,
          className: "jsx-2131122053",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 66
          },
          __self: this
        }, "click.."));
      })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a, {
        styleId: "2131122053",
        css: "section.jsx-2131122053{width:50%;border:1px solid gray;background-color:rgb(240,248,255);padding:1em;margin:1em;}.author.jsx-2131122053{font-style:italic;font-size:0.8em;}.img-article.jsx-2131122053{max-width:50%;}.newsMenu.jsx-2131122053{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;margin:0;padding:0;margin-top:20px;}.newsMenu.jsx-2131122053 li.jsx-2131122053{display:inline-table;padding--left:20px;}.newsMenu.jsx-2131122053 li.jsx-2131122053 a.jsx-2131122053{font-size:1em;color:blue;display:block;-webkit-text-decoration:none;text-decoration:none;}.newsMenu.jsx-2131122053 li.jsx-2131122053 a.jsx-2131122053:hover{color:rgb(255,187,0);-webkit-text-decoration:underline;text-decoration:underline;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xceDAwMTM2NzA4XFxEb3dubG9hZHNcXHBhZ2VzXFxwYWdlc1xccGFnZXNcXG5ld3MuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBc0VnQixBQUtnQixBQVFRLEFBSUosQUFHQSxBQU9RLEFBSVAsQUFNTyxVQS9CQSxJQVl0QixBQWNZLElBbEJJLEdBY0ksQUFVTyxJQUxaLE9BMUJxQixFQVFwQyxLQW1Cc0IsQ0FMdEIsMEJBckJZLFFBYVEsSUFaVCxHQThCWCxRQTdCQSxBQXlCQSxzREFiVSxTQUNDLFVBQ00sZ0JBQ2pCIiwiZmlsZSI6IkM6XFxVc2Vyc1xceDAwMTM2NzA4XFxEb3dubG9hZHNcXHBhZ2VzXFxwYWdlc1xccGFnZXNcXG5ld3MuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnO1xyXG5pbXBvcnQgZmV0Y2ggZnJvbSAnaXNvbW9ycGhpYy11bmZldGNoJztcclxuaW1wb3J0IFNlYXJjaEZvcm0gZnJvbSAnLi4vY29tcG9uZW50cy9TZWFyY2hGb3JtJztcclxuY29uc3QgYXBpS2V5ID0gJzM3ODAwNjZiMzNlZjQxYjliNGI3ZTk1Nzk5NGU5YzM4JztcclxuY29uc3QgZGVmYXVsdE5ld3NTb3VyY2UgPSAndGhlLWlyaXNoLXRpbWVzJ1xyXG5cdFx0XHRcclxuYXN5bmMgZnVuY3Rpb24gZ2V0TmV3cyh1cmwpIHtcclxudHJ5IHtcclxuXHRjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwpO1xyXG5cdGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG5cdHJldHVybiAoZGF0YSk7XHJcbn0gY2F0Y2ggKGVycm9yKSB7XHJcblx0cmV0dXJuIChlcnJvcik7XHJcbn1cclxufVx0XHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE5ld3MgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xyXG5cclxuY29uc3RydWN0b3IocHJvcHMpIHtcclxuXHRzdXBlcihwcm9wcylcclxuXHR0aGlzLnN0YXRlID0ge1xyXG5cdFx0bmV3c1NvdXJjZTogXCJcIixcclxuXHRcdHVybDogXCJcIixcclxuXHRcdGFydGljbGVzOiBbXVxyXG5cdH1cclxufSBcclxuXHJcbnNldE5ld3NTb3VyY2UgPSAoaW5wdXQpID0+IHtcclxuXHR0aGlzLnNldFN0YXRlKHtcclxuXHRcdG5ld3NTb3VyY2U6IGlucHV0LFxyXG5cdFx0dXJsOiBgaHR0cHM6Ly9uZXdzYXBpLm9yZy92Mi90b3AtaGVhZGxpbmVzP3NvdXJjZXM9JHtpbnB1dH0mYXBpS2V5PSR7YXBpS2V5fWBcclxuXHR9KVxyXG59XHJcbnJlbmRlcigpIHtcclxuXHJcblx0aWYgKHRoaXMuc3RhdGUuYXJ0aWNsZXMubGVuZ3RoID09IDApIHtcclxuXHJcblx0XHR0aGlzLnN0YXRlLmFydGljbGVzID0gdGhpcy5wcm9wcy5hcnRpY2xlcztcclxuXHJcblx0fVxyXG5cclxuXHRyZXR1cm4gKFxyXG5cclxuXHRcdDxkaXY+XHJcblx0XHQ8U2VhcmNoRm9ybSBzZXROZXdzU291cmNlPXt0aGlzLnNldE5ld3NTb3VyY2V9Lz5cclxuXHRcdFxyXG5cdFx0XHJcblx0XHQ8dWwgY2xhc3NOYW1lPVwibmV3c01lbnVcIj5cclxuXHRcdFx0PGxpPjxhIGhyZWY9XCJhXCIgb25DbGljaz17dGhpcy5zZWFyY2hOZXdzQVBJfSBuYW1lPVwidG9wLWhlYWRsaW5lcz9jb3VudHJ5PWllXCI+VG9wIEhlYWRsaW5lcyBJcmVsYW5kPC9hPjwvbGk+XHJcblx0XHRcdDxsaT48YSBocmVmPVwiYVwiIG9uQ2xpY2s9e3RoaXMuc2VhcmNoTmV3c0FQSX0gbmFtZT1cInRvcC1oZWFkbGluZXM/Y291bnRyeT1pZSZjYXRlZ29yeT1idXNpbmVzc1wiPkJ1c2luZXNzIE5ld3MgSXJlbGFuZDwvYT48L2xpPlxyXG5cdFx0XHQ8bGk+PGEgaHJlZj1cImFcIiBvbkNsaWNrPXt0aGlzLnNlYXJjaE5ld3NBUEl9IG5hbWU9XCJldmVyeXRoaW5nP3E9dGVjaG5vbG9neVwiPlRlY2hub2xvZ3kgTmV3czwvYT48L2xpPlxyXG5cdFx0XHQ8bGk+PGEgaHJlZj1cImFcIiBvbkNsaWNrPXt0aGlzLnNlYXJjaE5ld3NBUEl9IG5hbWU9XCJ0b3AtaGVhZGxpbmVzP2NvdW50cnk9aWUmY2F0ZWdvcnk9d2VhdGhlclwiPldlYXRoZXIgaW4gSXJlbGFuZDwvYT48L2xpPlxyXG5cdFx0PC91bD5cclxuXHRcdFxyXG5cdFx0PGgzPnt0aGlzLnN0YXRlLm5ld3NTb3VyY2Uuc3BsaXQoXCItXCIpLmpvaW4oXCIgXCIpfTwvaDM+XHJcblx0XHRcdDxkaXY+XHJcblxyXG5cclxuXHRcdFx0e3RoaXMuc3RhdGUuYXJ0aWNsZXMubWFwKChhcnRpY2xlLCBpbmRleCkgPT4gKFxyXG5cdFx0XHRcdDxzZWN0aW9uIGtleT17aW5kZXh9PlxyXG5cdFx0XHRcdDxoMz57YXJ0aWNsZS50aXRsZX08L2gzPlxyXG5cdFx0XHRcdDxwIGNsYXNzTmFtZT1cImF1dGhvclwiPnthcnRpY2xlLmF1dGhvcn0ge2FydGljbGUucHVibGlzaGVkQXR9PC9wPlxyXG5cdFx0XHRcdDxpbWcgc3JjPXthcnRpY2xlLnVybFRvSW1hZ2V9IGFsdD1cImFydGljbGUgaW1hZ2VcIiBjbGFzc05hbWU9XCJpbWctYXJ0aWNsZVwiPjwvaW1nPlxyXG5cdFx0XHRcdDxwPnthcnRpY2xlLmRlc2NyaXB0aW9ufTwvcD5cclxuXHRcdFx0XHQ8cD57YXJ0aWNsZS5jb250ZW50fTwvcD5cclxuXHRcdFx0XHQ8cD48TGluayBocmVmPVwiL3N0b3J5XCI+PGE+UmVhZCBNb3JlPC9hPjwvTGluaz48L3A+XHJcblx0XHRcdFx0PHAgb25DbGljaz17dGhpcy50ZXN0fT5jbGljay4uPC9wPlxyXG5cdFx0XHRcdDwvc2VjdGlvbj5cclxuXHRcdFx0KSl9XHJcblxyXG5cdFx0XHQ8L2Rpdj5cdFx0XHJcblx0XHRcdFx0PHN0eWxlIGpzeD57YFxyXG5cclxuXHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0c2VjdGlvbiB7XHJcblx0XHRcdFx0XHR3aWR0aDogNTAlO1xyXG5cdFx0XHRcdFx0Ym9yZGVyOiAxcHggc29saWQgZ3JheTtcclxuXHRcdFx0XHRcdGJhY2tncm91bmQtY29sb3I6IHJnYigyNDAsIDI0OCwgMjU1KTtcclxuXHRcdFx0XHRcdHBhZGRpbmc6IDFlbTtcclxuXHRcdFx0XHRcdG1hcmdpbjogMWVtO1xyXG5cdFx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHRcdC5hdXRob3Ige1xyXG5cdFx0XHRcdFx0Zm9udC1zdHlsZTogaXRhbGljO1xyXG5cdFx0XHRcdFx0Zm9udC1zaXplOiAwLjhlbTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdC5pbWctYXJ0aWNsZSB7XHJcblx0XHRcdFx0XHRtYXgtd2lkdGg6IDUwJTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdC5uZXdzTWVudXtcclxuXHRcdFx0XHRcdFx0ZGlzcGxheTogZmxleDtcclxuXHRcdFx0XHRcdFx0ZmxleC1kaXJlY3Rpb246IHJvdztcclxuXHRcdFx0XHRcdFx0bWFyZ2luOiAwO1xyXG5cdFx0XHRcdFx0XHRwYWRkaW5nOiAwO1xyXG5cdFx0XHRcdFx0XHRtYXJnaW4tdG9wOiAyMHB4O1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0Lm5ld3NNZW51IGxpe1xyXG5cdFx0XHRcdFx0XHRkaXNwbGF5OiBpbmxpbmUtdGFibGU7XHJcblx0XHRcdFx0XHRcdHBhZGRpbmctLWxlZnQ6IDIwcHg7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHQubmV3c01lbnUgbGkgYXtcclxuXHRcdFx0XHRcdFx0Zm9udC1zaXplOiAxZW07XHJcblx0XHRcdFx0XHRcdGNvbG9yOiBibHVlO1xyXG5cdFx0XHRcdFx0XHRkaXNwbGF5OiBibG9jaztcclxuXHRcdFx0XHRcdFx0dGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0Lm5ld3NNZW51IGxpIGE6aG92ZXIge1xyXG5cdFx0XHRcdFx0XHRjb2xvcjogcmdiKDI1NSwxODcsMCk7XHJcblx0XHRcdFx0XHRcdHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0YH1cclxuXHRcdFx0XHQ8L3N0eWxlPlxyXG5cclxuXHRcdDwvZGl2PlxyXG5cclxuXHQpO1xyXG5cclxufSBcclxuc3RhdGljIGFzeW5jIGdldEluaXRpYWxQcm9wcyhyZXNwb25zZSkge1xyXG5cdGNvbnN0IGluaXRVcmwgPSBgaHR0cHM6Ly9uZXdzYXBpLm9yZy92Mi90b3AtaGVhZGxpbmVzP3NvdXJjZXM9JHtkZWZhdWx0TmV3c1NvdXJjZX0mYXBpS2V5PSR7YXBpS2V5fWA7XHJcblx0Y29uc3QgZGF0YSA9IGF3YWl0IGdldE5ld3MoaW5pdFVybCk7XHJcblxyXG5cclxuXHJcblx0XHRpZiAoQXJyYXkuaXNBcnJheShkYXRhLmFydGljbGVzKSkge1xyXG5cclxuXHRcdFx0cmV0dXJuIHtcclxuXHRcdFx0XHRhcnRpY2xlczogZGF0YS5hcnRpY2xlc1xyXG5cclxuXHRcdFx0fVxyXG5cclxuXHRcdH1cclxuXHJcblxyXG5cdFx0ZWxzZSB7XHJcblxyXG5cdFx0XHRjb25zb2xlLmVycm9yKGRhdGEpXHJcblxyXG5cdFx0XHRcdGlmIChyZXNwb25zZSkge1xyXG5cclxuXHRcdFx0XHRyZXNwb25zZS5zdGF0dXNDb2RlID0gNDAwXHJcblxyXG5cdFx0XHRcdHJlc3BvbnNlLmVuZChkYXRhLm1lc3NhZ2UpO1xyXG5cclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0fVxyXG5cclxufVxyXG5hc3luYyBjb21wb25lbnREaWRVcGRhdGUocHJldlByb3BzLCBwcmV2U3RhdGUpIHtcclxuXHRpZiAodGhpcy5zdGF0ZS51cmwgIT09IHByZXZTdGF0ZS51cmwpIHtcclxuXHRcdGNvbnN0IGRhdGEgPSBhd2FpdCBnZXROZXdzKHRoaXMuc3RhdGUudXJsKTtcclxuXHRcdFx0aWYgKEFycmF5LmlzQXJyYXkoZGF0YS5hcnRpY2xlcykpIHtcclxuXHRcdFx0XHR0aGlzLnN0YXRlLmFydGljbGVzID0gZGF0YS5hcnRpY2xlcztcclxuXHRcdFx0XHR0aGlzLnNldFN0YXRlKHRoaXMuc3RhdGUpO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0ZWxzZSB7XHJcblx0XHRcdGNvbnNvbGUuZXJyb3IoZGF0YSlcclxuXHRcdFx0XHRpZiAocmVzcG9uc2UpIHtcclxuXHRcdFx0XHRcdHJlc3BvbnNlLnN0YXR1c0NvZGUgPSA0MDBcclxuXHRcdFx0XHRcdHJlc3BvbnNlLmVuZChkYXRhLm1lc3NhZ2UpO1xyXG5cclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0fVxyXG5cclxuXHR9XHJcblxyXG59IH1cclxuIl19 */\n/*@ sourceURL=C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js */",
        __self: this
      }));
    }
  }, {
    key: "componentDidUpdate",
    value: function () {
      var _componentDidUpdate = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(prevProps, prevState) {
        var data;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!(this.state.url !== prevState.url)) {
                  _context.next = 5;
                  break;
                }

                _context.next = 3;
                return getNews(this.state.url);

              case 3:
                data = _context.sent;

                if (Array.isArray(data.articles)) {
                  this.state.articles = data.articles;
                  this.setState(this.state);
                } else {
                  console.error(data);

                  if (response) {
                    response.statusCode = 400;
                    response.end(data.message);
                  }
                }

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      return function componentDidUpdate(_x2, _x3) {
        return _componentDidUpdate.apply(this, arguments);
      };
    }()
  }], [{
    key: "getInitialProps",
    value: function () {
      var _getInitialProps = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(response) {
        var initUrl, data;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                initUrl = "https://newsapi.org/v2/top-headlines?sources=".concat(defaultNewsSource, "&apiKey=").concat(apiKey);
                _context2.next = 3;
                return getNews(initUrl);

              case 3:
                data = _context2.sent;

                if (!Array.isArray(data.articles)) {
                  _context2.next = 8;
                  break;
                }

                return _context2.abrupt("return", {
                  articles: data.articles
                });

              case 8:
                console.error(data);

                if (response) {
                  response.statusCode = 400;
                  response.end(data.message);
                }

              case 10:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      return function getInitialProps(_x4) {
        return _getInitialProps.apply(this, arguments);
      };
    }()
  }]);

  return News;
}(react__WEBPACK_IMPORTED_MODULE_2___default.a.Component);


    (function (Component, route) {
      if(!Component) return
      if (false) {}
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/news")
  
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=news.js.7f3872296f485cf34981.hot-update.js.map