webpackHotUpdate("static\\development\\pages\\news.js",{

/***/ "./pages/news.js":
/*!***********************!*\
  !*** ./pages/news.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return News; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! isomorphic-unfetch */ "./node_modules/isomorphic-unfetch/browser.js");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_SearchForm__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/SearchForm */ "./components/SearchForm.js");

var _jsxFileName = "C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }




var apiKey = '3780066b33ef41b9b4b7e957994e9c38';
var defaultNewsSource = 'the-irish-times';

function getNews(_x) {
  return _getNews.apply(this, arguments);
}

function _getNews() {
  _getNews = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3(url) {
    var res, data;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            _context3.next = 3;
            return isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4___default()(url);

          case 3:
            res = _context3.sent;
            _context3.next = 6;
            return res.json();

          case 6:
            data = _context3.sent;
            return _context3.abrupt("return", data);

          case 10:
            _context3.prev = 10;
            _context3.t0 = _context3["catch"](0);
            return _context3.abrupt("return", _context3.t0);

          case 13:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 10]]);
  }));
  return _getNews.apply(this, arguments);
}

var News =
/*#__PURE__*/
function (_React$Component) {
  _inherits(News, _React$Component);

  function News(props) {
    var _this;

    _classCallCheck(this, News);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(News).call(this, props));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "setNewsSource", function (input) {
      _this.setState({
        newsSource: input,
        url: "https://newsapi.org/v2/top-headlines?sources=".concat(input, "&apiKey=").concat(apiKey)
      });
    });

    _this.state = {
      newsSource: "",
      url: "",
      articles: []
    };
    return _this;
  }

  _createClass(News, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      if (this.state.articles.length == 0) {
        this.state.articles = this.props.articles;
      }

      return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
        className: "jsx-4117342264",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 43
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_components_SearchForm__WEBPACK_IMPORTED_MODULE_5__["default"], {
        setNewsSource: this.setNewsSource,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 44
        },
        __self: this
      }), "//Navbar for things", react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("ul", {
        clasSName: "newsMenu",
        className: "jsx-4117342264",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 47
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("li", {
        className: "jsx-4117342264",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 48
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
        href: "a",
        onClick: this.searchNewsAPI,
        name: "top-headlines?country=ie",
        className: "jsx-4117342264",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 48
        },
        __self: this
      }, "Top Headlines Ireland")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("li", {
        className: "jsx-4117342264",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 49
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
        href: "a",
        onClick: this.searchNewsAPI,
        name: "top-headlines?country=ie&category=business",
        className: "jsx-4117342264",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 49
        },
        __self: this
      }, "Business News Ireland")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("li", {
        className: "jsx-4117342264",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 50
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
        href: "a",
        onClick: this.searchNewsAPI,
        name: "everything?q=technology",
        className: "jsx-4117342264",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 50
        },
        __self: this
      }, "Technology News")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("li", {
        className: "jsx-4117342264",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 51
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
        href: "a",
        onClick: this.searchNewsAPI,
        name: "top-headlines?country=ie&category=weather",
        className: "jsx-4117342264",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 51
        },
        __self: this
      }, "Weather in Ireland"))), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("h3", {
        className: "jsx-4117342264",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 54
        },
        __self: this
      }, this.state.newsSource.split("-").join(" ")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
        className: "jsx-4117342264",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 55
        },
        __self: this
      }, this.state.articles.map(function (article, index) {
        return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("section", {
          key: index,
          className: "jsx-4117342264",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 59
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("h3", {
          className: "jsx-4117342264",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 60
          },
          __self: this
        }, article.title), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4117342264" + " " + "author",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 61
          },
          __self: this
        }, article.author, " ", article.publishedAt), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("img", {
          src: article.urlToImage,
          alt: "article image",
          className: "jsx-4117342264" + " " + "img-article",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 62
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4117342264",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 63
          },
          __self: this
        }, article.description), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4117342264",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 64
          },
          __self: this
        }, article.content), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-4117342264",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 65
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
          href: "/story",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 65
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
          className: "jsx-4117342264",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 65
          },
          __self: this
        }, "Read More"))), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          onClick: _this2.test,
          className: "jsx-4117342264",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 66
          },
          __self: this
        }, "click.."));
      })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a, {
        styleId: "4117342264",
        css: "section.jsx-4117342264{width:50%;border:1px solid gray;background-color:rgb(240,248,255);padding:1em;margin:1em;}.author.jsx-4117342264{font-style:italic;font-size:0.8em;}.img-article.jsx-4117342264{max-width:50%;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xceDAwMTM2NzA4XFxEb3dubG9hZHNcXHBhZ2VzXFxwYWdlc1xccGFnZXNcXG5ld3MuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBc0VnQixBQUtnQixBQVFRLEFBSUosVUFYUSxJQVl0QixJQUpnQixjQVBvQixFQVFwQyxnQ0FQWSxZQUNELFdBQ1giLCJmaWxlIjoiQzpcXFVzZXJzXFx4MDAxMzY3MDhcXERvd25sb2Fkc1xccGFnZXNcXHBhZ2VzXFxwYWdlc1xcbmV3cy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluayc7XHJcbmltcG9ydCBmZXRjaCBmcm9tICdpc29tb3JwaGljLXVuZmV0Y2gnO1xyXG5pbXBvcnQgU2VhcmNoRm9ybSBmcm9tICcuLi9jb21wb25lbnRzL1NlYXJjaEZvcm0nO1xyXG5jb25zdCBhcGlLZXkgPSAnMzc4MDA2NmIzM2VmNDFiOWI0YjdlOTU3OTk0ZTljMzgnO1xyXG5jb25zdCBkZWZhdWx0TmV3c1NvdXJjZSA9ICd0aGUtaXJpc2gtdGltZXMnXHJcblx0XHRcdFxyXG5hc3luYyBmdW5jdGlvbiBnZXROZXdzKHVybCkge1xyXG50cnkge1xyXG5cdGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCk7XHJcblx0Y29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcblx0cmV0dXJuIChkYXRhKTtcclxufSBjYXRjaCAoZXJyb3IpIHtcclxuXHRyZXR1cm4gKGVycm9yKTtcclxufVxyXG59XHRcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTmV3cyBleHRlbmRzIFJlYWN0LkNvbXBvbmVudCB7XHJcblxyXG5jb25zdHJ1Y3Rvcihwcm9wcykge1xyXG5cdHN1cGVyKHByb3BzKVxyXG5cdHRoaXMuc3RhdGUgPSB7XHJcblx0XHRuZXdzU291cmNlOiBcIlwiLFxyXG5cdFx0dXJsOiBcIlwiLFxyXG5cdFx0YXJ0aWNsZXM6IFtdXHJcblx0fVxyXG59IFxyXG5cclxuc2V0TmV3c1NvdXJjZSA9IChpbnB1dCkgPT4ge1xyXG5cdHRoaXMuc2V0U3RhdGUoe1xyXG5cdFx0bmV3c1NvdXJjZTogaW5wdXQsXHJcblx0XHR1cmw6IGBodHRwczovL25ld3NhcGkub3JnL3YyL3RvcC1oZWFkbGluZXM/c291cmNlcz0ke2lucHV0fSZhcGlLZXk9JHthcGlLZXl9YFxyXG5cdH0pXHJcbn1cclxucmVuZGVyKCkge1xyXG5cclxuXHRpZiAodGhpcy5zdGF0ZS5hcnRpY2xlcy5sZW5ndGggPT0gMCkge1xyXG5cclxuXHRcdHRoaXMuc3RhdGUuYXJ0aWNsZXMgPSB0aGlzLnByb3BzLmFydGljbGVzO1xyXG5cclxuXHR9XHJcblxyXG5cdHJldHVybiAoXHJcblxyXG5cdFx0PGRpdj5cclxuXHRcdDxTZWFyY2hGb3JtIHNldE5ld3NTb3VyY2U9e3RoaXMuc2V0TmV3c1NvdXJjZX0vPlxyXG5cdFx0XHJcblx0XHQvL05hdmJhciBmb3IgdGhpbmdzXHJcblx0XHQ8dWwgY2xhc1NOYW1lPVwibmV3c01lbnVcIj5cclxuXHRcdFx0PGxpPjxhIGhyZWY9XCJhXCIgb25DbGljaz17dGhpcy5zZWFyY2hOZXdzQVBJfSBuYW1lPVwidG9wLWhlYWRsaW5lcz9jb3VudHJ5PWllXCI+VG9wIEhlYWRsaW5lcyBJcmVsYW5kPC9hPjwvbGk+XHJcblx0XHRcdDxsaT48YSBocmVmPVwiYVwiIG9uQ2xpY2s9e3RoaXMuc2VhcmNoTmV3c0FQSX0gbmFtZT1cInRvcC1oZWFkbGluZXM/Y291bnRyeT1pZSZjYXRlZ29yeT1idXNpbmVzc1wiPkJ1c2luZXNzIE5ld3MgSXJlbGFuZDwvYT48L2xpPlxyXG5cdFx0XHQ8bGk+PGEgaHJlZj1cImFcIiBvbkNsaWNrPXt0aGlzLnNlYXJjaE5ld3NBUEl9IG5hbWU9XCJldmVyeXRoaW5nP3E9dGVjaG5vbG9neVwiPlRlY2hub2xvZ3kgTmV3czwvYT48L2xpPlxyXG5cdFx0XHQ8bGk+PGEgaHJlZj1cImFcIiBvbkNsaWNrPXt0aGlzLnNlYXJjaE5ld3NBUEl9IG5hbWU9XCJ0b3AtaGVhZGxpbmVzP2NvdW50cnk9aWUmY2F0ZWdvcnk9d2VhdGhlclwiPldlYXRoZXIgaW4gSXJlbGFuZDwvYT48L2xpPlxyXG5cdFx0PC91bD5cclxuXHRcdFxyXG5cdFx0PGgzPnt0aGlzLnN0YXRlLm5ld3NTb3VyY2Uuc3BsaXQoXCItXCIpLmpvaW4oXCIgXCIpfTwvaDM+XHJcblx0XHRcdDxkaXY+XHJcblxyXG5cclxuXHRcdFx0e3RoaXMuc3RhdGUuYXJ0aWNsZXMubWFwKChhcnRpY2xlLCBpbmRleCkgPT4gKFxyXG5cdFx0XHRcdDxzZWN0aW9uIGtleT17aW5kZXh9PlxyXG5cdFx0XHRcdDxoMz57YXJ0aWNsZS50aXRsZX08L2gzPlxyXG5cdFx0XHRcdDxwIGNsYXNzTmFtZT1cImF1dGhvclwiPnthcnRpY2xlLmF1dGhvcn0ge2FydGljbGUucHVibGlzaGVkQXR9PC9wPlxyXG5cdFx0XHRcdDxpbWcgc3JjPXthcnRpY2xlLnVybFRvSW1hZ2V9IGFsdD1cImFydGljbGUgaW1hZ2VcIiBjbGFzc05hbWU9XCJpbWctYXJ0aWNsZVwiPjwvaW1nPlxyXG5cdFx0XHRcdDxwPnthcnRpY2xlLmRlc2NyaXB0aW9ufTwvcD5cclxuXHRcdFx0XHQ8cD57YXJ0aWNsZS5jb250ZW50fTwvcD5cclxuXHRcdFx0XHQ8cD48TGluayBocmVmPVwiL3N0b3J5XCI+PGE+UmVhZCBNb3JlPC9hPjwvTGluaz48L3A+XHJcblx0XHRcdFx0PHAgb25DbGljaz17dGhpcy50ZXN0fT5jbGljay4uPC9wPlxyXG5cdFx0XHRcdDwvc2VjdGlvbj5cclxuXHRcdFx0KSl9XHJcblxyXG5cdFx0XHQ8L2Rpdj5cdFx0XHJcblx0XHRcdFx0PHN0eWxlIGpzeD57YFxyXG5cclxuXHJcblx0XHRcdFx0XHRzZWN0aW9uIHtcclxuXHRcdFx0XHRcdHdpZHRoOiA1MCU7XHJcblx0XHRcdFx0XHRib3JkZXI6IDFweCBzb2xpZCBncmF5O1xyXG5cdFx0XHRcdFx0YmFja2dyb3VuZC1jb2xvcjogcmdiKDI0MCwgMjQ4LCAyNTUpO1xyXG5cdFx0XHRcdFx0cGFkZGluZzogMWVtO1xyXG5cdFx0XHRcdFx0bWFyZ2luOiAxZW07XHJcblx0XHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdFx0LmF1dGhvciB7XHJcblx0XHRcdFx0XHRmb250LXN0eWxlOiBpdGFsaWM7XHJcblx0XHRcdFx0XHRmb250LXNpemU6IDAuOGVtO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0LmltZy1hcnRpY2xlIHtcclxuXHRcdFx0XHRcdG1heC13aWR0aDogNTAlO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0YH1cclxuXHRcdFx0XHQ8L3N0eWxlPlxyXG5cclxuXHRcdDwvZGl2PlxyXG5cclxuXHQpO1xyXG5cclxufSBcclxuc3RhdGljIGFzeW5jIGdldEluaXRpYWxQcm9wcyhyZXNwb25zZSkge1xyXG5cdGNvbnN0IGluaXRVcmwgPSBgaHR0cHM6Ly9uZXdzYXBpLm9yZy92Mi90b3AtaGVhZGxpbmVzP3NvdXJjZXM9JHtkZWZhdWx0TmV3c1NvdXJjZX0mYXBpS2V5PSR7YXBpS2V5fWA7XHJcblx0Y29uc3QgZGF0YSA9IGF3YWl0IGdldE5ld3MoaW5pdFVybCk7XHJcblxyXG5cclxuXHJcblx0XHRpZiAoQXJyYXkuaXNBcnJheShkYXRhLmFydGljbGVzKSkge1xyXG5cclxuXHRcdFx0cmV0dXJuIHtcclxuXHRcdFx0XHRhcnRpY2xlczogZGF0YS5hcnRpY2xlc1xyXG5cclxuXHRcdFx0fVxyXG5cclxuXHRcdH1cclxuXHJcblxyXG5cdFx0ZWxzZSB7XHJcblxyXG5cdFx0XHRjb25zb2xlLmVycm9yKGRhdGEpXHJcblxyXG5cdFx0XHRcdGlmIChyZXNwb25zZSkge1xyXG5cclxuXHRcdFx0XHRyZXNwb25zZS5zdGF0dXNDb2RlID0gNDAwXHJcblxyXG5cdFx0XHRcdHJlc3BvbnNlLmVuZChkYXRhLm1lc3NhZ2UpO1xyXG5cclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0fVxyXG5cclxufVxyXG5hc3luYyBjb21wb25lbnREaWRVcGRhdGUocHJldlByb3BzLCBwcmV2U3RhdGUpIHtcclxuXHRpZiAodGhpcy5zdGF0ZS51cmwgIT09IHByZXZTdGF0ZS51cmwpIHtcclxuXHRcdGNvbnN0IGRhdGEgPSBhd2FpdCBnZXROZXdzKHRoaXMuc3RhdGUudXJsKTtcclxuXHRcdFx0aWYgKEFycmF5LmlzQXJyYXkoZGF0YS5hcnRpY2xlcykpIHtcclxuXHRcdFx0XHR0aGlzLnN0YXRlLmFydGljbGVzID0gZGF0YS5hcnRpY2xlcztcclxuXHRcdFx0XHR0aGlzLnNldFN0YXRlKHRoaXMuc3RhdGUpO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0ZWxzZSB7XHJcblx0XHRcdGNvbnNvbGUuZXJyb3IoZGF0YSlcclxuXHRcdFx0XHRpZiAocmVzcG9uc2UpIHtcclxuXHRcdFx0XHRcdHJlc3BvbnNlLnN0YXR1c0NvZGUgPSA0MDBcclxuXHRcdFx0XHRcdHJlc3BvbnNlLmVuZChkYXRhLm1lc3NhZ2UpO1xyXG5cclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0fVxyXG5cclxuXHR9XHJcblxyXG59IH1cclxuIl19 */\n/*@ sourceURL=C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js */",
        __self: this
      }));
    }
  }, {
    key: "componentDidUpdate",
    value: function () {
      var _componentDidUpdate = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(prevProps, prevState) {
        var data;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!(this.state.url !== prevState.url)) {
                  _context.next = 5;
                  break;
                }

                _context.next = 3;
                return getNews(this.state.url);

              case 3:
                data = _context.sent;

                if (Array.isArray(data.articles)) {
                  this.state.articles = data.articles;
                  this.setState(this.state);
                } else {
                  console.error(data);

                  if (response) {
                    response.statusCode = 400;
                    response.end(data.message);
                  }
                }

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      return function componentDidUpdate(_x2, _x3) {
        return _componentDidUpdate.apply(this, arguments);
      };
    }()
  }], [{
    key: "getInitialProps",
    value: function () {
      var _getInitialProps = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(response) {
        var initUrl, data;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                initUrl = "https://newsapi.org/v2/top-headlines?sources=".concat(defaultNewsSource, "&apiKey=").concat(apiKey);
                _context2.next = 3;
                return getNews(initUrl);

              case 3:
                data = _context2.sent;

                if (!Array.isArray(data.articles)) {
                  _context2.next = 8;
                  break;
                }

                return _context2.abrupt("return", {
                  articles: data.articles
                });

              case 8:
                console.error(data);

                if (response) {
                  response.statusCode = 400;
                  response.end(data.message);
                }

              case 10:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      return function getInitialProps(_x4) {
        return _getInitialProps.apply(this, arguments);
      };
    }()
  }]);

  return News;
}(react__WEBPACK_IMPORTED_MODULE_2___default.a.Component);


    (function (Component, route) {
      if(!Component) return
      if (false) {}
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/news")
  
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=news.js.1b02392dcb94ffc5bb44.hot-update.js.map