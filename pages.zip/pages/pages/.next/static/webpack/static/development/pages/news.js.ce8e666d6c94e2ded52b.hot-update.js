webpackHotUpdate("static\\development\\pages\\news.js",{

/***/ "./pages/news.js":
/*!***********************!*\
  !*** ./pages/news.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! isomorphic-unfetch */ "./node_modules/isomorphic-unfetch/browser.js");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_style_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/style.js */ "./components/style.js");
/* harmony import */ var _components_Meta__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Meta */ "./components/Meta.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);

var _jsxFileName = "C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js";


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function news(source) {
  console.log("hi");
}






var source = 'bbc-news';
var apiKey = '3780066b33ef41b9b4b7e957994e9c38';
var url = "https://newsapi.org/v2/top-headlines?sources=".concat(source, "&apikey=").concat(apiKey);

var News = function News(props) {
  return react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(_components_style_js__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 18
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("button", {
    onclick: "news('the-irish-times)",
    className: "jsx-1424727683",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 20
    },
    __self: this
  }, "Irish times"), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("h2", {
    className: "jsx-1424727683",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    },
    __self: this
  }, "News from ", source.split("-").join(" ")), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("div", {
    className: "jsx-1424727683",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    },
    __self: this
  }, props.articles.map(function (article) {
    return react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("section", {
      className: "jsx-1424727683",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 30
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("h3", {
      className: "jsx-1424727683",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 32
      },
      __self: this
    }, article.title), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("p", {
      className: "jsx-1424727683" + " " + "author",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 33
      },
      __self: this
    }, article.author, " ", article.publishedAt), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("img", {
      src: article.urlToImage,
      alt: "article image",
      className: "jsx-1424727683" + " " + "img-article",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 34
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("p", {
      className: "jsx-1424727683",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 35
      },
      __self: this
    }, article.description), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("p", {
      className: "jsx-1424727683",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 36
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
      hres: "/story",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 36
      },
      __self: this
    }, "Read more")));
  })), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a, {
    styleId: "1424727683",
    css: "h2.jsx-1424727683{color:red;}p.jsx-1424727683{color:blue;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xceDAwMTM2NzA4XFxEb3dubG9hZHNcXHBhZ2VzXFxwYWdlc1xccGFnZXNcXG5ld3MuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBMkNnQixBQUdrQixBQUdDLFVBRlosQ0FHQSIsImZpbGUiOiJDOlxcVXNlcnNcXHgwMDEzNjcwOFxcRG93bmxvYWRzXFxwYWdlc1xccGFnZXNcXHBhZ2VzXFxuZXdzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmZ1bmN0aW9uIG5ld3Moc291cmNlKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCJoaVwiKVx0XHJcblx0XHR9XHJcblx0XHJcblxyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcbmltcG9ydCBmZXRjaCBmcm9tICdpc29tb3JwaGljLXVuZmV0Y2gnO1xyXG5pbXBvcnQgTGF5b3V0IGZyb20gJy4uL2NvbXBvbmVudHMvc3R5bGUuanMnO1xyXG5pbXBvcnQgTWV0YSBmcm9tICcuLi9jb21wb25lbnRzL01ldGEnO1xyXG5pbXBvcnQgUmVhY3QsIHtDb21wb25lbnR9IGZyb20gJ3JlYWN0JztcclxuXHRjb25zdCBzb3VyY2UgPSAnYmJjLW5ld3MnO1xyXG5cdGNvbnN0IGFwaUtleSA9ICczNzgwMDY2YjMzZWY0MWI5YjRiN2U5NTc5OTRlOWMzOCc7XHJcblx0Y29uc3QgdXJsID0gYGh0dHBzOi8vbmV3c2FwaS5vcmcvdjIvdG9wLWhlYWRsaW5lcz9zb3VyY2VzPSR7c291cmNlfSZhcGlrZXk9JHthcGlLZXl9YDtcclxuXHJcblx0Y29uc3QgTmV3cyA9IHByb3BzID0+IChcclxuXHRcclxuXHRcdDxMYXlvdXQ+XHJcblxyXG4gIDxidXR0b24gb25jbGljaz1cIm5ld3MoJ3RoZS1pcmlzaC10aW1lcylcIj5JcmlzaCB0aW1lczwvYnV0dG9uPlxyXG5cclxuXHRcdFxyXG5cclxuXHJcblx0XHRcdDxoMj5OZXdzIGZyb20ge3NvdXJjZS5zcGxpdChcIi1cIikuam9pbihcIiBcIil9PC9oMj5cclxuXHRcdFx0XHJcblx0XHRcdDxkaXY+XHJcblxyXG5cdFx0XHRcdHtwcm9wcy5hcnRpY2xlcy5tYXAoYXJ0aWNsZSA9PiAoXHJcblx0XHRcdFx0XHQ8c2VjdGlvbj5cclxuXHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdDxoMz57YXJ0aWNsZS50aXRsZX08L2gzPlxyXG5cdFx0XHRcdFx0XHQ8cCBjbGFzc05hbWU9XCJhdXRob3JcIj57YXJ0aWNsZS5hdXRob3J9IHthcnRpY2xlLnB1Ymxpc2hlZEF0fTwvcD5cclxuXHRcdFx0XHRcdFx0PGltZyBzcmMgPSB7YXJ0aWNsZS51cmxUb0ltYWdlfSBhbHQgPSBcImFydGljbGUgaW1hZ2VcIiBjbGFzc05hbWU9XCJpbWctYXJ0aWNsZVwiPjwvaW1nPlxyXG5cdFx0XHRcdFx0XHQ8cD57YXJ0aWNsZS5kZXNjcmlwdGlvbn08L3A+XHJcblx0XHRcdFx0XHRcdDxwPjxMaW5rIGhyZXM9XCIvc3RvcnlcIj5SZWFkIG1vcmU8L0xpbms+PC9wPlxyXG5cdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdDwvc2VjdGlvbj5cclxuXHRcdFx0XHQpKX1cclxuXHRcdFx0XHQ8L2Rpdj5cclxuXHRcdFx0XHRcclxuXHRcdFx0XHJcblx0XHRcdFx0XHJcblx0XHRcdFx0PHN0eWxlIGpzeD57YFxyXG5cdFx0XHRcdFx0XHRoMntcclxuXHRcdFx0XHRcdFx0XHRjb2xvcjogcmVkO1xyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdHB7XHJcblx0XHRcdFx0XHRcdFx0Y29sb3I6IGJsdWU7XHJcblx0XHRcdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0YH1cclxuXHJcblx0XHRcdFx0XHQ8L3N0eWxlPlxyXG5cdFx0XHRcdDwvTGF5b3V0PlxyXG5cdFx0XHRcdFxyXG5cdFx0KTtcclxuXHJcblx0TmV3cy5nZXRJbml0aWFsUHJvcHMgPSBhc3luYyBmdW5jdGlvbigpe1xyXG5cdFx0Y29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsKTtcclxuXHRcdGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG5cdFx0XHJcblxyXG5cdFx0cmV0dXJuIHtcclxuXHRcdFx0YXJ0aWNsZXM6IGRhdGEuYXJ0aWNsZXNcclxuXHRcdH1cclxuXHR9XHJcblx0XHRleHBvcnQgZGVmYXVsdCBOZXdzOyJdfQ== */\n/*@ sourceURL=C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js */",
    __self: this
  }));
};

News.getInitialProps =
/*#__PURE__*/
_asyncToGenerator(
/*#__PURE__*/
_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
  var res, data;
  return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          _context.next = 2;
          return isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_3___default()(url);

        case 2:
          res = _context.sent;
          _context.next = 5;
          return res.json();

        case 5:
          data = _context.sent;
          return _context.abrupt("return", {
            articles: data.articles
          });

        case 7:
        case "end":
          return _context.stop();
      }
    }
  }, _callee, this);
}));
/* harmony default export */ __webpack_exports__["default"] = (News);
    (function (Component, route) {
      if(!Component) return
      if (false) {}
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/news")
  
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=news.js.ce8e666d6c94e2ded52b.hot-update.js.map