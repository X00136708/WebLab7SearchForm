webpackHotUpdate("static\\development\\pages\\news.js",{

/***/ "./pages/news.js":
/*!***********************!*\
  !*** ./pages/news.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! isomorphic-unfetch */ "./node_modules/isomorphic-unfetch/browser.js");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_style_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/style.js */ "./components/style.js");
/* harmony import */ var _components_Meta__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Meta */ "./components/Meta.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);

var _jsxFileName = "C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js";


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }






var source = 'the-irish-times';
var apiKey = '3780066b33ef41b9b4b7e957994e9c38';
var url = "https://newsapi.org/v2/top-headlines?sources=".concat(source, "&apikey=").concat(apiKey);
react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("script", {
  __source: {
    fileName: _jsxFileName,
    lineNumber: 11
  },
  __self: undefined
}, "function news(source)", console.log("hi"));

var News = function News(props) {
  return react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(_components_style_js__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 20
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("ul", {
    className: "jsx-1424727683",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("button", {
    onclick: "news('the-irish-times')",
    className: "jsx-1424727683",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    },
    __self: this
  }, "Irish times"), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("li", {
    className: "jsx-1424727683",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("a", {
    onclick: "news('abc-news')",
    className: "jsx-1424727683",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    },
    __self: this
  }, "ABC News")), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("li", {
    className: "jsx-1424727683",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("a", {
    onclick: "news('bbc-news')",
    className: "jsx-1424727683",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    },
    __self: this
  }, "BBC News"))), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("h2", {
    className: "jsx-1424727683",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    },
    __self: this
  }, "News from ", source.split("-").join(" ")), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("div", {
    className: "jsx-1424727683",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    },
    __self: this
  }, props.articles.map(function (article) {
    return react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("section", {
      className: "jsx-1424727683",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 38
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("h3", {
      className: "jsx-1424727683",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 40
      },
      __self: this
    }, article.title), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("p", {
      className: "jsx-1424727683" + " " + "author",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 41
      },
      __self: this
    }, article.author, " ", article.publishedAt), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("img", {
      src: article.urlToImage,
      alt: "article image",
      className: "jsx-1424727683" + " " + "img-article",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 42
      },
      __self: this
    }), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("p", {
      className: "jsx-1424727683",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 43
      },
      __self: this
    }, article.description), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("p", {
      className: "jsx-1424727683",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 44
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
      hres: "/story",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 44
      },
      __self: this
    }, "Read more")));
  })), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a, {
    styleId: "1424727683",
    css: "h2.jsx-1424727683{color:red;}p.jsx-1424727683{color:blue;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xceDAwMTM2NzA4XFxEb3dubG9hZHNcXHBhZ2VzXFxwYWdlc1xccGFnZXNcXG5ld3MuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBbURnQixBQUdrQixBQUdDLFVBRlosQ0FHQSIsImZpbGUiOiJDOlxcVXNlcnNcXHgwMDEzNjcwOFxcRG93bmxvYWRzXFxwYWdlc1xccGFnZXNcXHBhZ2VzXFxuZXdzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xyXG5pbXBvcnQgZmV0Y2ggZnJvbSAnaXNvbW9ycGhpYy11bmZldGNoJztcclxuaW1wb3J0IExheW91dCBmcm9tICcuLi9jb21wb25lbnRzL3N0eWxlLmpzJztcclxuaW1wb3J0IE1ldGEgZnJvbSAnLi4vY29tcG9uZW50cy9NZXRhJztcclxuaW1wb3J0IFJlYWN0LCB7Q29tcG9uZW50fSBmcm9tICdyZWFjdCc7XHJcblx0Y29uc3Qgc291cmNlID0gJ3RoZS1pcmlzaC10aW1lcyc7XHJcblx0Y29uc3QgYXBpS2V5ID0gJzM3ODAwNjZiMzNlZjQxYjliNGI3ZTk1Nzk5NGU5YzM4JztcclxuXHRjb25zdCB1cmwgPSBgaHR0cHM6Ly9uZXdzYXBpLm9yZy92Mi90b3AtaGVhZGxpbmVzP3NvdXJjZXM9JHtzb3VyY2V9JmFwaWtleT0ke2FwaUtleX1gO1xyXG5cdFxyXG5cdFxyXG5cdDxzY3JpcHQ+XHJcblx0XHRmdW5jdGlvbiBuZXdzKHNvdXJjZSl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwiaGlcIilcdFxyXG5cdFx0fVxyXG5cdDwvc2NyaXB0PlxyXG5cdFxyXG5cdFxyXG5cdGNvbnN0IE5ld3MgPSBwcm9wcyA9PiAoXHJcblx0XHJcblx0XHQ8TGF5b3V0PlxyXG5cdFx0XHRcclxuXHJcblxyXG5cclxuXHRcdFx0XHJcbjx1bD5cclxuICA8YnV0dG9uIG9uY2xpY2s9IFwibmV3cygndGhlLWlyaXNoLXRpbWVzJylcIiA+SXJpc2ggdGltZXM8L2J1dHRvbj5cclxuICA8bGk+PGEgb25jbGljaz0gXCJuZXdzKCdhYmMtbmV3cycpXCI+QUJDIE5ld3M8L2E+PC9saT5cclxuICA8bGk+PGEgb25jbGljaz0gXCJuZXdzKCdiYmMtbmV3cycpXCI+QkJDIE5ld3M8L2E+PC9saT5cclxuPC91bD5cdFx0XHJcblxyXG5cclxuXHRcdFx0PGgyPk5ld3MgZnJvbSB7c291cmNlLnNwbGl0KFwiLVwiKS5qb2luKFwiIFwiKX08L2gyPlxyXG5cdFx0XHRcclxuXHRcdFx0PGRpdj5cclxuXHJcblx0XHRcdFx0e3Byb3BzLmFydGljbGVzLm1hcChhcnRpY2xlID0+IChcclxuXHRcdFx0XHRcdDxzZWN0aW9uPlxyXG5cdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0PGgzPnthcnRpY2xlLnRpdGxlfTwvaDM+XHJcblx0XHRcdFx0XHRcdDxwIGNsYXNzTmFtZT1cImF1dGhvclwiPnthcnRpY2xlLmF1dGhvcn0ge2FydGljbGUucHVibGlzaGVkQXR9PC9wPlxyXG5cdFx0XHRcdFx0XHQ8aW1nIHNyYyA9IHthcnRpY2xlLnVybFRvSW1hZ2V9IGFsdCA9IFwiYXJ0aWNsZSBpbWFnZVwiIGNsYXNzTmFtZT1cImltZy1hcnRpY2xlXCI+PC9pbWc+XHJcblx0XHRcdFx0XHRcdDxwPnthcnRpY2xlLmRlc2NyaXB0aW9ufTwvcD5cclxuXHRcdFx0XHRcdFx0PHA+PExpbmsgaHJlcz1cIi9zdG9yeVwiPlJlYWQgbW9yZTwvTGluaz48L3A+XHJcblx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0PC9zZWN0aW9uPlxyXG5cdFx0XHRcdCkpfVxyXG5cdFx0XHRcdDwvZGl2PlxyXG5cdFx0XHRcdFxyXG5cdFx0XHRcclxuXHRcdFx0XHRcclxuXHRcdFx0XHQ8c3R5bGUganN4PntgXHJcblx0XHRcdFx0XHRcdGgye1xyXG5cdFx0XHRcdFx0XHRcdGNvbG9yOiByZWQ7XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0cHtcclxuXHRcdFx0XHRcdFx0XHRjb2xvcjogYmx1ZTtcclxuXHRcdFx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRgfVxyXG5cclxuXHRcdFx0XHRcdDwvc3R5bGU+XHJcblx0XHRcdFx0PC9MYXlvdXQ+XHJcblx0XHRcdFx0XHJcblx0XHQpO1xyXG5cclxuXHROZXdzLmdldEluaXRpYWxQcm9wcyA9IGFzeW5jIGZ1bmN0aW9uKCl7XHJcblx0XHRjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwpO1xyXG5cdFx0Y29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcblx0XHRcclxuXHJcblx0XHRyZXR1cm4ge1xyXG5cdFx0XHRhcnRpY2xlczogZGF0YS5hcnRpY2xlc1xyXG5cdFx0fVxyXG5cdH1cclxuXHRcdGV4cG9ydCBkZWZhdWx0IE5ld3M7Il19 */\n/*@ sourceURL=C:\\Users\\x00136708\\Downloads\\pages\\pages\\pages\\news.js */",
    __self: this
  }));
};

News.getInitialProps =
/*#__PURE__*/
_asyncToGenerator(
/*#__PURE__*/
_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
  var res, data;
  return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          _context.next = 2;
          return isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_3___default()(url);

        case 2:
          res = _context.sent;
          _context.next = 5;
          return res.json();

        case 5:
          data = _context.sent;
          return _context.abrupt("return", {
            articles: data.articles
          });

        case 7:
        case "end":
          return _context.stop();
      }
    }
  }, _callee, this);
}));
/* harmony default export */ __webpack_exports__["default"] = (News);
    (function (Component, route) {
      if(!Component) return
      if (false) {}
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/news")
  
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=news.js.de75b5aa688c96781c14.hot-update.js.map